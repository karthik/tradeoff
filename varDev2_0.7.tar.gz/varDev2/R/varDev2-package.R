

#' ~~ Methods for Function plot ~~
#'
#' ~~ Methods for function \code{plot} ~~
#'
#'
#' @name plot-methods
#' @aliases plot-methods plot,ANY,ANY-method
#' @docType methods
#' @section Methods: \describe{
#'
#' \item{x = "ANY", y = "ANY"}{ ~~describe this method here }
#'
#' \item{x = "ANY", y = "VD.dist"}{ ~~describe this method here }
#'
#' \item{x = "VD.SASD", y = "ANY"}{ ~~describe this method here }
#'
#' \item{x = "VD.dist", y = "ANY"}{ ~~describe this method here } }
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @keywords methods
NULL





#' Return vector of stage names for a variable development model.
#'
#' See \linkS4class{VD.model} and \linkS4class{VD.sim}.
#'
#'
#' @name stage.names-methods
#' @aliases stage.names stage.names-methods stage.names,ANY-method
#' @docType methods
#' @section Methods: \describe{
#'
#' \item{VD = "ANY"}{ ~~describe this method here }
#'
#' \item{VD = "VD.model"}{ ~~describe this method here }
#'
#' \item{VD = "VD.sim"}{ ~~describe this method here } }
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
NULL





#' Package for variable or stochastic development models of biologically
#' stage-structured population dynamics
#'
#' Matrix population models are limited in their ability to accommodate
#' variation in stage durations.  This package allows demographic analysis of
#' stage-structured dynamics where each stage can have a distribution of stage
#' durations (development times), which may be correlated, and a distribution
#' of age-within-stage of death (mortality).  Demographic analysis includes
#' long-term population growth rate, stable age-stage distribution, and
#' sensitivities obtained by sequential Monte Carlo numerical integration.
#'
#' \tabular{ll}{ Package: \tab varDev\cr Type: \tab Package\cr Version: \tab
#' 0.6\cr Date: \tab 2009-10-07\cr License: \tab GPL version 2.0 or greater\cr
#' LazyLoad: \tab yes\cr Depends: \tab methods\cr } Models are defined with
#' \link{VD.model}.  Distributions are defined by \link{VD.dist}.  Sequential
#' Monte Carlo simulations are run by \link{VD.run}.  Stable age-stage
#' distribution is obtained by \link{make.SASD}.  Long-term growth rate is
#' obtained by \link{VD.solve.euler}.  Derivatives of long-term growth rate
#' with respect to model parameters are obtained by
#' \link{VD.deriv.growth.rate}.
#'
#' @name varDev-package
#' @aliases varDev-package varDev
#' @docType package
#' @author Perry de Valpine
#'
#' Maintainer: Perry de Valpine <pdevalpine@@berkeley.edu>
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
#' @keywords package
NULL





#' Class "VD.dist"
#'
#' Represents probability distributions for use by stochastic (or variable)
#' development model simulations.  Contains a call to each of a "p", "d", "q",
#' and "r" distribution function (see basic documentation, such as
#' \code{?dnorm}), with parameters fixed.  These calls can be run by methods
#' \code{VD.dist.calc} and \code{VD.dist.deriv}, which have facilities for
#' changing parameters, obtaining a numerical derivative, and discretizing
#' continuous random variables to integers (by rounding up).  Discrete
#' distributions represented by \code{VD.dist} objects must have support on (1,
#' 2, 3, ...), not (0, 1, 2, 3, ...).  This suits the definitions of variable
#' development models but differs from standard distributions.  See
#' \link{dgeomp1}.
#'
#'
#' @name VD.dist-class
#' @aliases VD.dist-class initialize,VD.dist-method plot,ANY,VD.dist-method
#' plot,VD.dist,ANY-method
#' @docType class
#' @section Objects from the Class:
#'
#' Objects can be created by calls of the form \code{new("VD.dist",
#' distribution.name, params = NULL, pdf.derivs = NULL, cdf.derivs = NULL,
#' quantile.derivs = NULL)}.
#'
#' A wrapper function \code{\link{VD.dist}(distribution.name, params,
#' pdf.derivs, cdf.derivs, quantile.derivs)} is also available.
#'
#' See \code{\link{VD.dist}} for full description of arguments.  Note that
#' \code{distribution.name} \emph{omits} the "p", "d", "q", or "r", and the
#' class \emph{requires} that some or all of these (depending on how it will be
#' used) be defined with the same arguments, as is standard for 's usual
#' distribution functions.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.dist.calc}}, \code{\link{VD.dist.deriv}},
#' \code{link{dgeomp1}}, \code{\link{dinfinite}}. Introduction and examples can
#' be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
NULL





#' Class "VD.fec"
#'
#' A class for fecundity calculations as a function of age and/or
#' age-at-maturity for stochastic (or variable) development models.  Objects of
#' this class hold functions and parameters for the fecundity calculations (to
#' be accessed using \code{\link{VD.fec.calc}}) and possibly for derivatives of
#' fecundity (to be called using \code{\link{VD.fec.deriv}}) with respect to
#' parameters.  Derivative can be calculated numerically even if appropriate
#' functions are not given.
#'
#'
#' @name VD.fec-class
#' @aliases VD.fec-class initialize,VD.fec-method
#' @docType class
#' @note The general approach of \code{VD.fec} is similar to that of
#' \code{\linkS4class{VD.dist}}.
#' @section Objects from the Class:
#'
#' Objects can be created by calls of the form \code{new("VD.fec",
#' fecundity.function, params = NULL, derivative.functions = NULL)}.
#'
#' A wrapper for this is \code{\link{VD.fec}(fecundity.function, params = NULL,
#' derivative.functions = NULL)}.  See that help page for details of how the
#' fecundity functions should be set up.
#' @author Perry de Valpine
#' @seealso \code{\linkS4class{VD.dist}}, \code{\link{VD.fec.calc}},
#' \code{\link{VD.fec.deriv}}, \code{VD.fec} for details of how the fecundity
#' functions should be set up. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
NULL





#' Class "VD.model"
#'
#' \code{VD.model} contains the model definition for a stochastic (or variable)
#' development model of biologically stage-structured population dynamics.  It
#' includes definitions of marginal stage duration distributions, an optional
#' Gaussian copula distribution to define correlations among stage durations,
#' definitions of stage-specific mortality, an optional fecundity model, and
#' control parameters.
#'
#'
#' @name VD.model-class
#' @aliases VD.model-class initialize,VD.model-method
#' all.independent,VD.model-method all.independent controls,VD.model-method
#' controls-methods controls,ANY-method controls<-,VD.model-method controls<-
#' controls<--methods controls<-,ANY-method fecundity,VD.model-method
#' fecundity,ANY-method fecundity-methods fecundity fecundity<-,VD.model-method
#' fecundity<--methods fecundity<-,ANY-method fecundity<-
#' gauss.cov,VD.model-method gauss.cov,ANY-method gauss.cov gauss.cov-methods
#' initialize,VD.model-method marginal.death.times,VD.model-method
#' marginal.death.times,ANY-method marginal.death.times-methods
#' marginal.death.times marginal.death.times<-,VD.model-method
#' marginal.death.times<-,ANY-method marginal.death.times<--methods
#' marginal.death.times<- marginal.durations,VD.model-method
#' marginal.durations,ANY-method marginal.durations-methods marginal.durations
#' marginal.durations<-,VD.model-method marginal.durations<-,ANY-method
#' marginal.durations<--methods marginal.durations<- num.stages,VD.model-method
#' num.stages,ANY-method num.stages-methods num.stages
#' stage.independent,VD.model-method stage.independent,ANY-method
#' stage.independent-methods stage.independent stage.names,VD.model-method
#' stage.names<-,VD.model-method stage.names<-,ANY-method stage.names<--methods
#' stage.names<-
#' @docType class
#' @section Objects from the Class:
#'
#' Objects can be created by calls of the form \code{new("VD.model",
#' num.stages, marginal.durations, marginal.death.times, fecundity, controls,
#' stage.names, gauss.cov)}.
#'
#' A slightlier friendlier method is provided by
#' \code{\link{VD.model}(num.stages, marginal.durations, marginal.death.times,
#' fecundity, controls, stage.names, gauss.cov)}
#' @author Perry de Valpine
#' @seealso \code{\linkS4class{VD.dist}}, \code{\linkS4class{VD.fec}},
#' \code{\link{VD.run}}, \code{\link{VD.run.stage}}. Introduction and examples
#' can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
NULL





#' Class to represent stable age-stage distribution of a variable development
#' model
#'
#' This class contains a list of information calculated by
#' \code{\link{make.SASD}} from a \linkS4class{VD.sim} object.  It gets its own
#' class label so it can have a plot method.
#'
#'
#' @name VD.SASD-class
#' @aliases VD.SASD-class plot,VD.SASD,ANY-method VD.mean.age
#' VD.mean.age-methods VD.mean.age,ANY-method VD.mean.age,VD.SASD-method
#' VD.mode.age VD.mode.age-methods VD.mode.age,ANY-method
#' VD.mode.age,VD.SASD-method
#' @docType class
#' @section Objects from the Class: Objects can be created by calls of the form
#' \code{new("VD.SASD", ...)} or by \code{\link{as.VD.SASD}}, which is what
#' \code{\link{make.SASD}} uses.
#' @author Perry de Valpine
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
#' @keywords classes
NULL





#' Class "VD.sim"
#'
#' Contains sequential Monte Carlo results for a variable (or stochastic)
#' development model of biologically stage-structured population dynamics.
#'
#'
#' @name VD.sim-class
#' @aliases VD.sim-class initialize,VD.sim-method num.stages,VD.sim-method
#' simulation.summary,VD.sim-method simulation.summary,ANY-method
#' simulation.summary-methods simulation.summary
#' simulation.summary<-,VD.sim-method simulation.summary<-,ANY-method
#' simulation.summary<--methods simulation.summary<- stage.names,VD.sim-method
#' stageMC,VD.sim-method stageMC,ANY-method stageMC-methods stageMC
#' stageMC<-,VD.sim-method stageMC<-,ANY-method stageMC<--methods stageMC<-
#' @docType class
#' @section Objects from the Class: Objects can be created by calls of the form
#' \code{new("VD.sim", VDM)}.
#'
#' A slightly friendlier way to create objects is given by
#' \code{\link{VD.sim}(VDM)}.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.sim}}, \code{\link{VD.run}},
#' \code{\link{VD.run.stage}}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
#' @keywords classes
NULL



