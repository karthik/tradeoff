## Distribution class for variable development models

setClass("VD.dist",
         representation(params = "list",
                        distribution.functions = "list",
                        deriv.functions = "list"))

setMethod("initialize", "VD.dist",
          function(.Object, distribution.name, params = NULL, pdf.derivs = NULL, cdf.derivs = NULL, quantile.derivs = NULL) {
            
            if(class(distribution.name) != "character") stop("Error, in initialize for VD.dist, distribution.name should be a character string.");
            
            .Object@params <- c(list(1), params); 
            calc.names <- c("pdf","cdf", "random", "quantile");
            calc.prefixes <- c("d","p","r","q");
            function.names <- paste(calc.prefixes, distribution.name, sep="");
            for(i in seq(1, along = calc.names)) {
              .Object@distribution.functions[[calc.names[i]]] <- eval.parent(as.name(function.names[i]));
            }
            
            for(deriv.type in c("pdf", "cdf", "quantile")) {
              deriv.name <- paste(deriv.type, ".derivs", sep="");
              this.derivs <- eval(substitute(dn, list(dn = as.name(deriv.name))));
              if(!is.null(this.derivs)) {
                .Object@deriv.functions[[deriv.type]] <- this.derivs
              }
            }
            .Object
          })

setMethod("plot",
          signature(y = "VD.dist"),
          function(x, y, lower.quantile = 0, upper.quantile = 0.9999, cdf = FALSE, ...) {
            browser();
            if(missing(x)) {
              x.range <- ceiling(VD.dist.calc(c(lower.quantile, upper.quantile), y, "quantile"));
              x <- x.range[1]:x.range[2];
            }
            probability <- VD.dist.calc(x, y, if(cdf) "cdf" else "pdf");
            callGeneric(x, probability, ...); 
          }
          )

setMethod("plot",
          signature(x = "VD.dist"),
          function(x, y, ...) {
            browser();
            if(!missing(y)) writeLines("Warning: y is ignored");
            callGeneric(y = x, ...); 
          }
          )




#' Create a new VD.dist object
#' 
#' This is a wrapper for \code{new("VD.dist", ...)}.  This is the recommended
#' way to generate new \linkS4class{VD.dist} objects.
#' 
#' 
#' @param distribution.name A character string of a distribution function name
#' \emph{without} the "p", "d", "q", or "r".  For example
#' \code{distribution.name = "gamma"} will be used internally to get functions
#' \code{pgamma}, \code{dgamma}, etc. \emph{from the calling environment}, i.e.
#' scoped as if the functions had been passed as arguments.
#' @param params A list with names that are argument names for the "p", "d",
#' "q", and "r" distribution functions and values that are the parameter
#' values.  This is used as the second argument of a \code{do.call} call.
#' @param pdf.derivs Optional.  A list with names of parameters and contents
#' that are functions returning derivatives of the probability density, or "d",
#' function.  For example, if \code{norm.deriv.mean} is a function returning
#' the derivative of the normal pdf with respect to the mean, then using
#' \code{pdf.derivs = list(mean = norm.deriv.mean)} tells the VD.dist object
#' about \code{norm.deriv.mean}.  The derivative functions \emph{must} take the
#' same parameters as the other distribution functions.
#' @param cdf.derivs Similar to \code{pdf.derivs}, but for derivatives of the
#' cumulative density, or "p", function.
#' @param quantile.derivs Similar to \code{pdf.derivs}, but for derivatives of
#' the quantile, or "q", function.
#' @return An object of class \linkS4class{VD.dist}.
#' @section Warning: There is not much type checking to catch mistakes in a
#' user-friendly way.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.dist.calc}}, \code{\link{VD.dist.deriv}},
#' \code{\linkS4class{VD.dist}}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.dist <- function(distribution.name, params = NULL, pdf.derivs = NULL, cdf.derivs = NULL, quantile.derivs = NULL) {
  new("VD.dist", distribution.name = distribution.name, params = params, pdf.derivs = pdf.derivs, cdf.derivs = cdf.derivs, quantile.derivs = quantile.derivs)
}



#' Do distribution calls for a VD.dist object
#' 
#' \code{VD.dist} objects contain calls to a family of distribution functions
#' organized in the usual way as "p", "d", "q", and "r" functions for
#' cumulative, density, quantile, and random, respectively (e.g. \code{pnorm},
#' \code{dnorm}, \code{qnorm}, and \code{rnorm}) with fixed (but adjustable)
#' parameters.  \code{VD.dist.calc} is the interface for calling the functions
#' managed by a \code{VD.dist} object.  For the stochastic (or variable)
#' development models, this provides a way to encapsulate a model definition
#' that a model component follows a particular distribution.  It also handles
#' discretization of continuous distributions.
#' 
#' 
#' @param x The object to be passed as the \emph{first} argument to any of the
#' distribution functions, regardless how the first argument is named in those
#' functions.  For example, the first argument to \code{qnorm} is \code{p}, but
#' here it is passed as \code{x} (but named \code{p} is the subsequent call to
#' \code{qnorm} generated by the \code{VD.dist} object \code{distr}).
#' @param distr An object of class \code{VD.dist} that knows what distribution
#' functions to call.
#' @param calc One of "pdf", "cdf", "quantile", or "random", corresponding to
#' whichever function should be called.
#' @param make.discrete If \code{TRUE}, treat the distribution as having domain
#' of the integers, \strong{starting at 1}.  For continuous distributions, the
#' probability of \code{x} is treated as the integral from \code{floor(x)} to
#' \code{ceiling(x)}.  This has no effect when \code{calc} is "quantile" or
#' "random".
#' @param new.params An optional list of parameters to replace or add in the
#' parameter list of \code{distr}.  For example, \code{new.params =
#' list(lower.tail = FALSE)} would either change (if already present) or insert
#' (if not present) the \code{lower.tail} argument as \code{FALSE} in the call
#' generated to the "d", "p", "q", or "r" function.
#' @return Whatever would normally be returned by a call the the "p", "d", "q"
#' or "r" function.  For example, if \code{distr = \link{VD.dist}(norm(mean =
#' 5, sd = 2))}, then \code{VD.dist.calc} with \code{calc = "quantile"} returns
#' whatever is returned by \code{qnorm}.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.dist.deriv}}. Introduction and examples can be found
#' by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.dist.calc <- function(x, distr, calc, make.discrete = FALSE, new.params = NULL) {
  if(class(distr) != "VD.dist") {stop("error, must supply an object of class VD.dist");}
  do.new.params <- !is.null(new.params);
  if(!make.discrete) {
    updated.params <- distr@params;
    updated.params[[1]] <- as.name("x");
    if(!do.new.params) {
      return(do.call(distr@distribution.functions[[calc]], updated.params))
    } 
    replace.indices <- match(names(new.params), names(updated.params), 0);
    updated.params[replace.indices] <- new.params[replace.indices > 0];
    other.params <- new.params[replace.indices == 0];
    lnc <- length(updated.params);
    if(length(other.params) > 0) {
      for(i in 1:length(other.params)) {
        updated.params[[lnc + i]] <- other.params[[i]];
      }
      names(updated.params)[lnc + 1:length(other.params)] <- names(other.params);
    }
    return(do.call(distr@distribution.functions[[calc]], updated.params))
  } else {
    if(!(calc %in% c("pdf", "cdf"))) {stop("Error: make.discrete only makes sense for calc = \"pdf\" or \"cdf\" ");}
    updated.params <- distr@params;
    if(calc == "pdf") {
      ceil.x <- ceiling(x);
      range.ceil.x <- range(ceil.x);
      seq.x <- (range.ceil.x[1]-1):range.ceil.x[2];
      updated.params[[1]] <- as.name("seq.x");
    } else {
      ceil.x <- ceiling(x);
      updated.params[[1]] <- as.name("ceil.x");
    }
    if(do.new.params) {
      replace.indices <- match(names(new.params), names(updated.params), 0);
      updated.params[replace.indices] <- new.params[replace.indices > 0]
      other.params <- new.params[replace.indices == 0];
      lnc <- length(updated.params)
      if(length(other.params) > 0) {
        for(i in 1:length(other.params)) {
          updated.params[[lnc + i]] <- other.params[[i]]
        }
        names(updated.params)[lnc + 1:length(other.params)] <- names(other.params);
      }
    }
    if(calc == "pdf") {
      pdf.vals <- diff(do.call(distr@distribution.functions[["cdf"]], updated.params));
      return(pdf.vals[ceil.x - range.ceil.x[1] + 1])
    } else {
      return(do.call(distr@distribution.functions[[calc]], updated.params));
    }
  }
}



#' Derivatives of probability calculations using a VD.dist object.
#' 
#' \code{VD.dist} objects encapsulate calls to a family of distribution
#' functions, such as the normal family represented by \code{pnorm},
#' \code{dnorm}, \code{qnorm}, and \code{rnorm}.  This function calculates
#' derivatives of the first three of these.  It uses either numerical methods
#' or derivative functions that may have been supplied when creating the
#' \code{VD.dist} object.
#' 
#' 
#' @param x Whatever the \emph{first} argument to the "p", "d", or "q" function
#' should be.
#' @param distr An object of class \code{VD.dist}
#' @param calc One of "pdf", "cdf", or "quantile"
#' @param param The parameter name, as a string, with respect to which the
#' derivative should be calculated
#' @param force.numerical If \code{TRUE}, a numerical derivative will be used
#' regardless of whether \code{VD.dist} knows of an appropriate derivative
#' function.
#' @param delta Small change in the parameter value used for calculating a
#' numerical derivative.
#' @param make.discrete If \code{TRUE}, the distributions are treated as having
#' integer domain \strong{starting at 1}.  See \code{\link{VD.dist.calc}}.
#' @param relative If \code{TRUE}, return the derivative divided by the
#' function call itself.  Useful for demographic sensitivity calculations using
#' importance sampling.
#' @param new.params Optional list of parameters to replace or insert in the
#' distribution function call.  See \code{\link{VD.dist.calc}}.
#' @return Derivatives or relative derivatives in whatever form \code{x} was
#' provided.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.dist.calc}}, \code{\linkS4class{VD.dist}}.
#' Introduction and examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.dist.deriv <- function(x, distr, calc, param, force.numerical = FALSE, delta = 0.0001, make.discrete = FALSE, relative = FALSE, new.params = NULL) {
  if(class(distr) != "VD.dist") {stop("error, must supply an object of class VD.dist");}
  if(calc == "random") {stop("error, does not make sense to take derivatives of the random generator");}
  do.new.params <- !is.null(new.params);
  do.numerical <- TRUE
  if(!force.numerical) {
    do.numerical <- !(param %in% names(distr@deriv.functions[[calc]]))
  }
  if(!do.numerical) {
    if(make.discrete) {writeLines("Warning: make.discrete = TRUE has no impact since you are calling a supplied derivative function.")}
    updated.params <- distr@params;
    updated.params[[1]] <- as.name("x");
    if(do.new.params) {
      replace.indices <- match(names(new.params), names(updated.params), 0);
      updated.params[replace.indices] <- new.params[replace.indices > 0] 
      other.params <- new.params[replace.indices == 0];
      lnc <- length(updated.params)
      if(length(other.params) > 0) {
        for(i in 1:length(other.params)) {
          updated.params[[lnc + i]] <- other.params[[i]]
        }
        names(updated.params)[lnc + 1:length(other.params)] <- names(other.params);
      }
    }

    if(!relative) {
      return(do.call(distr@deriv.functions[[calc]][[param]], updated.params));
    } else {
      return(do.call(distr@deriv.functions[[calc]][[param]], updated.params) / VD.dist.calc(x, distr, calc, make.discrete, new.params = new.params));
    }
  } else {
    vals <- VD.dist.calc(x, distr, calc, make.discrete, new.params = new.params);
    param.plus.delta <- distr@params[[param]] + delta
    new.new.params <- list()
    new.new.params[[param]] <- param.plus.delta;
    new.params <- c(new.new.params, new.params);
    plus.delta.vals <-VD.dist.calc(x, distr, calc, make.discrete, new.params = new.params);

    if(!relative) {
      return( ( plus.delta.vals - vals ) / delta );
    } else {
      return( ( ( plus.delta.vals / vals ) - 1 ) / delta )
    }
  }
}


