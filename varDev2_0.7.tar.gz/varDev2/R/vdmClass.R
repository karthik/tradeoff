## Variable Development Model class

setClass("VD.model",
         representation(num.stages = "integer",
                        stage.names = "character",
                        stage.independent = "logical",
                        all.independent = "logical",
                        gauss.cov = "matrix",
                        gauss.inv.cov = "matrix",
                        det.cov = "numeric",
                        marginal.duration.dists = "list",
                        marginal.death.time.dists = "list",
                        fecundity = "VD.fec",


#' Return the controls table for a variable development model
#' 
#' The controls table contains various settings that determine how sequential
#' Monte Carlo sampling is done.
#' 
#' Controls determines the size of simulation batches, the stopping criteria,
#' and whether all simulations should be saved.  Simulation goes batch-by-batch
#' until stopping criteria are reached.  Stopping criteria and multiple and can
#' be redundant (so do not all need to be specified), allowing some
#' flexibility.  Specific uses of stopping criteria are determined by
#' \link{VD.run.stage}.
#' 
#' @param VDM An object of class \linkS4class{VD.model}, a variable development
#' model.
#' @return A data frame with rows corresponding to stages and the following
#' columns: \item{batch.size }{How many stage durations and mortalities should
#' be simulated in one batch?  } \item{alive.target}{Stopping criteria in terms
#' of minimum number of simulations desired that survive the stage}
#' \item{dead.target}{Stopping criteria in terms of minimum number of
#' simulations desired that die in the stage} \item{max.dead}{Stopping criteria
#' in terms of maximum number of simulations desired that die in the stage}
#' \item{max.total}{Stopping criteria in terms of total number of simulations
#' after which to stop no matter what} \item{ragged.save}{If \code{TRUE} for a
#' stage, record simulations even beyond \code{alive.target} or
#' \code{dead.target} if simulation is proceeding because other stopping
#' criteria have not been met.  If \code{FALSE}, throw out simulations beyond
#' \code{alive.target} or \code{dead.target} (but still count them to estimate
#' survival rates, etc.).}
#' @author Perry de Valpine
#' @seealso \linkS4class{VD.model}, \code{\link{VD.run}}.
#' \code{\link{VD.run.stage}}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
                        controls = "data.frame"))

marginal.durations <- function(VDM) {
  warning("marginal.durations expects VDM to be a VD.model");
}
`marginal.durations<-` <- function(VDM, value) {
  warning("marginal.durations<- expects VDM to be a VD.model");
}
setGeneric("marginal.durations")

setMethod("marginal.durations", "VD.model",
          function(VDM) {
            VDM@marginal.duration.dists
          })
setReplaceMethod("marginal.durations", signature(VDM = "VD.model"),
          function(VDM, value) {
            VDM@marginal.duration.dists <- value
            VDM
            }
          )

marginal.death.times <- function(VDM) {
  warning("marginal.death.times expects VDM to be a VD.model");
}

`marginal.death.times<-` <- function(VDM, value) {
  warning("marginal.death.times<- expects VDM to be a VD.model");
}
setGeneric("marginal.death.times")

setMethod("marginal.death.times", "VD.model",
          function(VDM) {
            VDM@marginal.death.time.dists
          })
setReplaceMethod("marginal.death.times", signature(VDM = "VD.model"),
          function(VDM, value) {
            VDM@marginal.death.time.dists <- value
            VDM
            }
          )

fecundity <- function(VDM) {
  warning("fecundity expects VDM to be a VD.model");
}
`fecundity<-` <- function(VDM, value) {
  warning("fecundity<- expects VDM to be a VD.model");
}
setGeneric("fecundity")

setMethod("fecundity", "VD.model",
          function(VDM) {
            VDM@fecundity
          })
setReplaceMethod("fecundity", signature(VDM = "VD.model"),
          function(VDM, value) {
            VDM@fecundity <- value
            VDM
            }
          )

controls <- function(VDM) {
  warning("controls expects VDM to be a VD.model");
}
`controls<-` <- function(VDM, value) {
  warning("controls<- expects VDM to be a VD.model");
}
setGeneric("controls")

setMethod("controls", "VD.model",
          function(VDM) {
            VDM@controls
          })
setReplaceMethod("controls", signature(VDM = "VD.model"),
          function(VDM, value) {
            VDM@controls <- value
            VDM
            }
          )

gauss.cov <- function(VDM) {
  warning("gauss.cov expects VDM to be a VD.model");
}
setGeneric("gauss.cov")
setMethod("gauss.cov", "VD.model",
          function(VDM) {
            VDM@gauss.cov
          })

stage.independent <- function(VDM) {
  warning("stage.independent expects VDM to be a VD.model");
}
setGeneric("stage.independent")
setMethod("stage.independent", "VD.model",
          function(VDM) {
            VDM@stage.independent
          })

all.independent <- function(VDM) {
  warning("all.independent expects VDM to be a VD.model");
}
setGeneric("all.independent")
setMethod("all.independent", "VD.model",
          function(VDM) {
            VDM@all.independent
          })

num.stages <- function(VD) {
  warning("num.stages expects VD to be a VD.model");
}
setGeneric("num.stages")
setMethod("num.stages", "VD.model",
          function(VD) {
            VD@num.stages
          })

stage.names <- function(VD) {
  warning("stage.names expects VD to be a VD.model");
}
`stage.names<-` <- function(VD, value) {
  warning("stage.names<- expects VD to be a VD.model");
}
setGeneric("stage.names")

setMethod("stage.names", "VD.model",
          function(VD) {
            VD@stage.names
          })
setReplaceMethod("stage.names", signature(VD = "VD.model"),
          function(VD, value) {
            VD@stage.names <- value
            VD
            }
          )


setMethod("initialize", "VD.model",
          function(.Object, num.stages, marginal.durations, marginal.death.times, fecundity = NULL,
                   controls = NULL, stage.names = NULL, gauss.cov = NULL) {

            if(is.null(fecundity)) warning("Warning: no fecundity specified.  You can simulate development and survival, but you will need to specific fecundity to find population growth rate and other results.")

            .Object@num.stages <- as.integer(num.stages)
            if(is.null(stage.names)) stage.names <- paste("Stage", 1:num.stages, sep = "");
            .Object@stage.names <-stage.names

            .Object@all.independent <-is.null(gauss.cov)
            if(!.Object@all.independent) {
              if(ncol(gauss.cov) != nrow(gauss.cov)) {stop("Error: gauss.cov must be a square matrix");}
              if(any(diag(gauss.cov) != 1)) {stop("Error: gauss.cov must have 1's on the diagonal");}
              .Object@gauss.cov <- gauss.cov
              .Object@gauss.inv.cov <- solve(gauss.cov);
              .Object@det.cov <- det(gauss.cov);
            }
            .Object@stage.independent <- c(TRUE, rep(.Object@all.independent, num.stages - 1)); # can be improved to pick out independent stages.

            .Object@marginal.duration.dists <- marginal.durations;
            .Object@marginal.death.time.dists <- marginal.death.times;

            if(class(fecundity) %in% c("numeric", "integer")) {
              .Object@fecundity <- VD.fec(VD.fecundity.constant, list(m = fecundity))
            } else {
              if(!is.null(fecundity)) .Object@fecundity <- fecundity;
            }

            if(!is.null(controls)) {
              .Object@controls <- controls;
            } else {
              .Object@controls <- VD.controls(num.stages);
            }
            .Object
          }
          )



#' Make default controls for variable development model simulation
#' 
#' The controls data frame of a \linkS4class{VD.model} object determine how
#' \code{\link{VD.run}} simulates sequential Monte Carlo (SMC) samples. The SMC
#' method simulates individuals that die in or survive through each stage. This
#' function returns a valid controls data frame.  By default it is called with
#' its default arguments when a new VD.model object is created without
#' otherwise specifying controls.
#' 
#' 
#' @param num.stages Number of stages in the model
#' @param batch.size How many life schedules should be simulated in each batch
#' @param alive.target Number of simulations that live through the stage
#' required before stopping for that stage.
#' @param dead.target Number of simulations that die in the stage required
#' before stopping for that stage.
#' @param max.dead Maximum number of simulations that die in the stage.
#' @param max.total Absolute maximum number of simulations after which stopping
#' is enforced no matter what other conditions are or are not met.
#' @param ragged.save If TRUE, all simulations are saved when possible.  If
#' FALSE, only the target number of simulations are saved.  For example, if
#' \code{dead.target} has already been met but \code{alive.target} has not,
#' then if \code{ragged.save} is TRUE, additional dead simulations will be
#' saved while continuing until \code{alive.target} is met.
#' @return A data frame with columns matching the input arguments are rows for
#' each stage.
#' @author Perry de Valpine
#' @seealso \link{VD.run.stage}, \linkS4class{VD.model}, \link{controls}.
#' Introduction and examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.controls <- function(num.stages, batch.size = 5000, alive.target = 10000, dead.target =  c(rep(10000, num.stages - 1), 0), max.dead = 20000, max.total = 100000, ragged.save = TRUE) {
  ans <-  structure(data.frame(matrix(nrow = num.stages, ncol = 6)), names = c("batch.size", "alive.target", "dead.target", "max.dead", "max.total", "ragged.save"))
  ans[,"batch.size"] <- if(length(batch.size) == 1) rep(batch.size, num.stages) else batch.size;
  ans[,"alive.target"] <-  if(length(alive.target) == 1) rep(alive.target, num.stages) else alive.target;
  ans[,"dead.target"] <- if(length(dead.target) == 1) rep(dead.target, num.stages) else dead.target;
  ans[,"max.dead"] <- if(length(max.dead) == 1) rep(max.dead, num.stages) else max.dead;
  ans[,"max.total"] <- if(length(max.total) == 1) rep(max.total, num.stages) else max.total;
  ans[,"ragged.save"] <- if(length(ragged.save) == 1) rep(ragged.save, num.stages) else ragged.save;
  ans
}



#' Create a VD.model object defining a variable (or stochastic) development
#' model.
#' 
#' Takes arguments that specify a variable development model for biologically
#' stage-structured dynamics and returns a \code{\linkS4class{VD.model}}
#' object.
#' 
#' 
#' @param num.stages Number of life stages
#' @param marginal.durations List of length \code{num.stages}, with each entry
#' an object of class \code{\linkS4class{VD.dist}} defining a marginal stage
#' duration distribution for a life stage, in order.
#' @param marginal.death.times Similar to \code{marginal.durations}, but for
#' age-within-stage-of-death distributions.
#' @param fecundity Optional object of class \code{\link{VD.fec}} defining
#' fecundity for the final stage.
#' @param controls Controls used for sequential Monte Carlo simulation by
#' \code{\link{VD.run}} and \code{\link{VD.run.stage}}.  If omitted, default
#' controls are used.
#' @param stage.names Vector of strings of length \code{num.stages}, giving
#' labels for the life stages.  If omitted, labels will be "Stage1", "Stage2",
#' etc.
#' @param gauss.cov Optional \code{num.stages}-by-\code{num.stages} matrix
#' giving covariance matrix for Gaussian copula model defining correlations
#' among stage-duration distributions.
#' @return An object of class \code{\linkS4class{VD.model}}.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.run}}, \code{\link{VD.run.stage}}. Introduction and
#' examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.model <- function(num.stages, marginal.durations, marginal.death.times, fecundity = NULL, controls = NULL, stage.names = NULL, gauss.cov = NULL) {
  if(class(marginal.durations) != "list") {stop("Error: marginal.durations should be a list");}
  if(length(marginal.durations) != num.stages) {stop("Error: length(marginal.durations) should equal num.stages");}
  if(class(marginal.death.times) != "list") {stop("Error: marginal.death.times should be a list");}
  if(length(marginal.death.times) != num.stages) {stop("Error: length(marginal.death.times) should equal num.stages");}

  new("VD.model", num.stages, marginal.durations, marginal.death.times, fecundity, controls, stage.names, gauss.cov);
}

setClass("VD.sim",
         representation(simulation.summary = "data.frame",
                        stageMC = "list",
                        stage.names = "character",
                        num.stages = "integer"))

setMethod("initialize", "VD.sim",
          function(.Object, VDM) {
            if(class(VDM) == "VD.model") {
              .Object@num.stages <- VDM@num.stages
              .Object@stage.names <- VDM@stage.names
            } else {
              .Object@num.stages <- as.integer(VDM);
              .Object@stage.names <- paste("Stage", 1:.Object@num.stages, sep = "");
            }
            .Object@simulation.summary <- structure(data.frame(matrix(nrow = .Object@num.stages, ncol = 7)),
                                           names = c("Stage",
                                             "prob.surv.stage",
                                             "total.count",
                                             "total.alive",
                                             "total.dead",
                                             "discarded.alive",
                                             "discarded.dead"))

            .Object@stageMC <- list();
            .Object
          }
          )

setMethod("num.stages", "VD.sim",
          function(VD) {
            VD@num.stages
          })

setMethod("stage.names", "VD.sim",
          function(VD) {
            VD@stage.names
          })

simulation.summary <- function(VDS) {
  warning("simulation.summary expects VDS to be a VD.sim");
}
setGeneric("simulation.summary")
setMethod("simulation.summary", "VD.sim",
          function(VDS) {
            VDS@simulation.summary
          })
`simulation.summary<-` <- function(VDS, value) {
  warning("simulation.summary<- expects VDS to be a VD.sim");
}
setReplaceMethod("simulation.summary", signature(VDS = "VD.sim"),
          function(VDS, value) {
            VDS@simulation.summary <- value
            VDS
            }
          )


stageMC <- function(VDS) {
  warning("stageMC expects VDS to be a VD.sim");
}
setGeneric("stageMC")
setMethod("stageMC", "VD.sim",
          function(VDS) {
            VDS@stageMC
          })

`stageMC<-` <- function(VDS, value) {
  warning("stageMC<- expects VDS to be a VD.sim");
}
setReplaceMethod("stageMC", signature(VDS = "VD.sim"),
          function(VDS, value) {
            VDS@stageMC <- value
            VDS
            }
          )



#' Make a new object of class VD.sim
#' 
#' \code{\linkS4class{VD.sim}} objects contain sequential Monte Carlo
#' simulation results of variable (stochastic) development models of
#' biologically stage-structured population dynamics.  This function creates a
#' new object.
#' 
#' Every \code{VD.sim} object is viewed as being defined by its
#' \code{VD.model}.  A complete copy of the \code{VD.model} is not kept in the
#' \code{VD.sim} object.
#' 
#' @param VDM An object of class \code{\linkS4class{VD.model}} defining a
#' variable development model.
#' @return A \code{VD.sim} object.
#' @author Perry de Valpine
#' @seealso \code{\linkS4class{VD.sim}}. Introduction and examples can be found
#' by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.sim <- function(VDM) {
  new("VD.sim", VDM)
}

setClass("VD.SASD", contains = "list");


#' Turn a list into a VD.SASD object
#' 
#' Turn a list into a VD.SASD (Variable development stable age-stage
#' distribution) object for variable development sequential Monte Carlo samples
#' 
#' This is used in \code{\link{make.SASD}}.  It simply calls \code{as(x,
#' "VD.SASD")}.
#' 
#' @param x A list appropriate to be a \linkS4class{VD.SASD} object.
#' @return A VD.SASD object
#' @author Perry de Valpine
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
as.VD.SASD <- function(x) {as(x, "VD.SASD");}
setMethod("plot", "VD.SASD",
          function(x, y, age.vector, two.axes, two.axes.threshold, use.right.axis,
                   main = "Stable age-stage distribution",
                   xlab = "Age",
                   ylab="Stable age-stage fraction",
                   left.lty = "solid",
                   right.lty = "dotted",
                   left.col = "black",
                   right.col = left.col,
                   right.axis.factor = 1,
                   lwd = 1, add = FALSE,  ...) {
            if(missing(age.vector)) {
              age.vector <- x$age.vector;
            }

            i.max.age <- length(age.vector);
            num.stages <- dim(x$SASD)[2];
            scale.factors <- rep(1, num.stages);
            ltys <- rep(left.lty, num.stages);
            cols <- rep(left.col, num.stages);
            stage.peaks <- apply(x$SASD[1:i.max.age,], 2, max);

            if(!add) {
              range.peaks <- range(stage.peaks);
              if(missing(two.axes.threshold))
                if(missing(right.axis.factor)) two.axes.threshold <- 4 else two.axes.threshold <- right.axis.factor - 0.00000001;
              if(missing(two.axes)) two.axes <- (range.peaks[2] / range.peaks[1] >= two.axes.threshold)

              if(two.axes) {
                if(missing(use.right.axis)) {
                  largest.small.peak <- max(stage.peaks[ range.peaks[2] / stage.peaks  >= two.axes.threshold])
                  use.right.axis <- stage.peaks <= largest.small.peak
                  if(missing(right.axis.factor)) right.axis.factor <- range.peaks[2] / largest.small.peak;
                } else {
                  if(missing(right.axis.factor)) right.axis.factor <- range.peaks[2] / max(stage.peaks[use.right.axis]);
                }
                ltys[use.right.axis] <- right.lty;
                cols[use.right.axis] <- right.col;
                scale.factors[use.right.axis] <- right.axis.factor;
                par(mar = c(5,4,4,4) + 0.1);
              }
              plot(range(age.vector), c(0, range.peaks[2]), type = "n", main = main, xlab = xlab, ylab = ylab)
              if(two.axes) {
                axvals <- pretty(par("usr")[3:4] / right.axis.factor);
                axis(side = 4, at = axvals * right.axis.factor, labels = axvals)
              }
            } else {

              y.range <- par()$usr[3:4];
              y.max <- y.range[2] - (diff(y.range)*(1 - 1/1.08))/2
              if(!missing(right.axis.factor)) {
                if(missing(use.right.axis)) {
                  use.right.axis <- stage.peaks <= y.max / right.axis.factor;
                }
                scale.factors[use.right.axis] <- right.axis.factor;
                ltys[use.right.axis] <- right.lty;
                cols[use.right.axis] <- right.col;
              }
            }
            for(i.stage in 1:num.stages) {
              points(age.vector, x$SASD[1:i.max.age, i.stage]*scale.factors[i.stage], type = "l", lty = ltys[i.stage], col = cols[i.stage], lwd = lwd)
            }
            right.axis.factor
          })

VD.mean.age <- function(SASD) {
  warning("Warning: you should not be getting to default VD.mean.age method")
}
setMethod("VD.mean.age", "VD.SASD",
          function(SASD) {
            apply( SASD$SASD, 2, function(x) {sum(x * SASD$age.vector)} ) / SASD$SSD;
          })

VD.mode.age <- function(SASD) {
  warning("Warning: you should not be getting to default VD.mode.age method")
}

setMethod("VD.mode.age", "VD.SASD",
          function(SASD) {
            SASD$age.vector[apply( SASD$SASD, 2, which.max)]
          })

