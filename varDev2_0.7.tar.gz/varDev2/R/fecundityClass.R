## Class for fecundity calculations for a variable development model

setClass("VD.fec",
          representation(params = "list",
                         fecundity.function = "function",
                         derivative.functions = "list"))

setMethod("initialize", "VD.fec",
          function(.Object, fecundity.function, params = NULL, derivative.functions = NULL) {
            .Object@fecundity.function <- if(is.character(fecundity.function)) {
              eval.parent(as.name(fecundity.function));
            } else {
              fecundity.function
            }
            .Object@params <- c(list(age = as.name("age"), age.maturity = as.name("age.maturity")), params);
                       
            if(!is.null(derivative.functions)) {
              for(n in names(derivative.functions)) {
                .Object@derivative.functions[[n]] <- if(is.character(derivative.functions[[n]])) {
                  eval.parent(as.name(derivative.functions[[n]]))
                } else {
                  derivative.functions[[n]]
                }
              }
            }            
            .Object
          }
          )



#' Construct new objects of class VD.fec
#' 
#' This is a wrapper for \code{new("VD.fec", ...).}.
#' 

#' 
#' When \code{\link{VD.fec.calc}} or \code{\link{VD.fec.deriv}} is called, the
#' \code{function} object \code{fecundity.function} and/or the ones in
#' \code{derivative.functions} are called.
#' 
#' @param fecundity.function A function object that \strong{must} take as its
#' first argument a vector named \code{age} and as its second argument a
#' corresponding vector named \code{age.maturity} of ages at maturity.  It must
#' return a corresponding vector of fecundities during the time-step that leads
#' to the given ages.  This allows fecundity to depend on either absolute age
#' or age within the reproductive (assumed to be the final) stage.
#' @param params A list with names that are argument names for
#' \code{fecundity.function} and values that are the parameter values.  This is
#' used as the second argument of a \code{do.call} call.
#' @param derivative.functions An optional list of function objects, omitting
#' the first two arguments as just described, that return fecundity
#' derivatives.  The list names must be the names of the parameters with
#' respect to which the derivatives are taken.  If these are not provided,
#' derivatives will be calculated numerically.
#' @return An object of class \code{\linkS4class{VD.fec}}.
#' @section Warning: Little or no checking of the validity of
#' \code{fecundity.function} or \code{derivative.functions} is done
#' @author Perry de Valpine
#' @seealso
#' 
#' \code{\linkS4class{VD.fec}}, \code{\link{VD.fec.calc}},
#' \code{\link{VD.fec.deriv}}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.fec <- function(fecundity.function, params = NULL, derivative.functions = NULL ) {
  new("VD.fec", fecundity.function = fecundity.function, params = params, derivative.functions = derivative.functions);
}



#' Do fecundity calculations for stochastic (or variable) development model
#' using a VD.fec object
#' 
#' \code{VD.fec} objects encapsulate the fecundity model used for a stochastic
#' development model, allowing its parameters to be set up once, re-used, and
#' manipulated such as for numerical derivatives.  \code{VD.fec.calc} is the
#' main function to use a \code{VD.fec} object to calculate fecundities.
#' \code{VD.fec.deriv} calculates derivatives.
#' 
#' \code{VD.fec.calc} calls the fecundity function.
#' 
#' \code{VD.fec.deriv} calls the derivative functions or calculates a numerical
#' derivative.
#' 
#' @aliases VD.fec.calc VD.fec.deriv
#' @param age Vector of ages for which fecundity should be calculated.  This is
#' passed as the first argument to the fecundity functions managed by
#' \code{VD.fec}.
#' @param age.maturity Vector of ages of maturity for which fecundity should be
#' calculated.  This is aligned with \code{age}.  This is passed as the second
#' argument to the fecundity functions managed by \code{VD.fec}.
#' @param VD.fec An object of class \code{\linkS4class{VD.fec}}
#' @param new.params Optional list of replacement parameters, with names that
#' are parameter names. (Unlike the similar \code{\link{VD.fec.calc}}, this
#' does not allow new parameters to be inserted.  It could, but this has not
#' been needed.)
#' @param param Character string of the parameter name with respect to which
#' the derivative should be taken.
#' @param force.numerical If \code{TRUE}, the derivative will be done
#' numerically even if a derivative function is available to the \code{VD.fec}
#' object.
#' @param delta Small value to be added to the parameter value when calculating
#' a numerical derivative
#' @return For \code{VD.fec.calc}, whatever is returned by the call to the
#' fecundity function by \code{VD.fec}, which should be a vector of fecundity
#' values aligned with the \code{age} and \code{age.maturing} vectors.
#' 
#' For \code{VD.fec.deriv}, whatever is returned by the call to the derivative
#' function by \code{VD.fec}, or by the numerical derivative using
#' \code{VD.fec.calc}.  In any case this should be a vector aligned with the
#' \code{age} and \code{age.maturing} vectors.
#' @author Perry de Valpine
#' @seealso \code{\linkS4class{VD.fec}}, \code{\link{VD.dist}}. Introduction
#' and examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.fec.calc <- function(age, age.maturity, VD.fec, new.params = NULL) {
  if(class(VD.fec) != "VD.fec") { stop("Error, must supply an object of class VD.fec");}

  do.new.params <- !is.null(new.params);
  if(!do.new.params) {
    return(do.call(VD.fec@fecundity.function, VD.fec@params));
  }
  updated.params <- VD.fec@params;
  replace.indices <- match(names(new.params), names(updated.params), 0)
  updated.params[replace.indices] <- new.params[replace.indices > 0];
  return(do.call(VD.fec@fecundity.function, updated.params))
}

VD.fec.deriv <- function(age, age.maturity, VD.fec, param, force.numerical = FALSE, delta = 0.0001) {
  do.numerical <- TRUE;
  if(!force.numerical) {
    do.numerical <- !(param %in% names(VD.fec@derivcalls));
  }
  if(!do.numerical) {
    newcall <- VD.fec@derivcalls[[param]];
    newcall[[2]] <- as.name("age");
    newcall[[3]] <- as.name("age.maturity");
    return(eval(newcall));
  }
  new.params <- list();
  new.params[[param]] <- VD.fec@params[[param]] + delta;
  ans <- (VD.fec.calc(age, age.maturity, VD.fec, new.params = new.params) - VD.fec.calc(age, age.maturity, VD.fec)) / delta;
  return(ans);
}
