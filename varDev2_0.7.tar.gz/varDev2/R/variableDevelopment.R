## Code for demographic analysis of variable development models using
## Monte Carlo integration of the Euler equation




#' Do fecundity calculations for constant fecundity in a stochastic (or
#' variable) development model.  This is trivial but necessary to allow the
#' generality of fecundity functions.
#' 
#' This function returns the same constant fecundity value in a vector as long
#' as the vectors of ages and ages-at-maturity for which fecundity is
#' requested.
#' 
#' 
#' @param age Vector of ages for which fecundity is requested
#' @param age.maturity Vector of age-at-maturity for which fecundity is
#' requested
#' @param F Constant value of fecundity
#' @return A vector the same length as \code{age} and \code{age.maturity}
#' containing \code{m} in every element.
#' @author Perry de Valpine
#' @seealso \code{\linkS4class{VD.fec}}, \code{\link{VD.fec.calc}}.
#' Introduction and examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.fecundity.constant <- function(age, age.maturity, F) {
  return(rep(F, length(age.maturity)));
}



#' Dummy functions for a distribution that always results in infinite values
#' 
#' For variable development models, it is useful to treat survival in a uniform
#' way, even if there is no mortality so survival is perfect.  In terms of the
#' distribution of age at death (or age-within-stage at death), this requires
#' an distribution that is always infinite.  In such a case, the stage duration
#' in the model (\linkS4class{VD.model}) takes care of maturation, which, for
#' the last stage, is interpreted as mortality.
#' 
#' 
#' @aliases dinfinite pinfinite qinfinite rinfinite
#' @param x dummy for a random value
#' @param p dummy for a quantile
#' @param n number of random values requested
#' @param ... additional arguments that may be passed along (and not used)
#' @return \code{dinfinite} and \code{pinfinite} return \code{NA}'s.
#' \code{qinfinite} and \code{rinfinite} return \code{Inf}'s.
#' @author Perry de Valpine
#' @seealso \linkS4class{VD.model}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
dinfinite <- function(x) {rep(NA, length(x));}
qinfinite<- function(p,...) {rep(NA, length(p));}
pinfinite <- function(x) {rep(1, length(x));}
rinfinite <- function(n) {rep(Inf, n);}



#' Distribution functions for a geometric-plus-one distribution
#' 
#' The standard geometric distribution in treats the possible random values as
#' starting at zero.  For a variable development model it is necessary for it
#' to start at 1.  These functions call the corresponding \link{dgeom},
#' \link{pgeom}, \link{rgeom}, and \link{qgeom} with arguments adjusted by 1.
#' 
#' \code{dgeomp1} and \code{pgeomp1} call \code{\link{dgeom}} and
#' \code{\link{pgeom}}, respectively, with \code{x-1}.  \code{qgeomp1} and
#' \code{rgeomp1} call \code{qgeom} and \code{rgeom}, respectively, and add 1
#' to the answer.
#' 
#' @aliases dgeomp1 pgeomp1 rgeomp1 qgeomp1
#' @param x Value for which the probability or cumulative probability is
#' requested
#' @param prob prob parameter of a geometric distribution, see \link{dgeom}
#' @param p Quantile
#' @param n Number of random values requested
#' @param ... Any other arguments to pass the pgeom or qgeom
#' @return See the correponding \code{[d,p,q,r]geom} functions.
#' @author Perry de Valpine
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
dgeomp1 <- function(x, prob) {dgeom(x-1, prob);}
qgeomp1 <- function(p, prob, ...) {qgeom(p, prob, ...) + 1;}
rgeomp1 <- function(n, prob) {rgeom(n, prob) + 1;}
pgeomp1 <- function(x, prob, ...) {pgeom(x-1, prob, ...);}




#' Run a stochastic (or variable) development population model
#' 
#' Generate sequential Monte Carlo samples from a model defined by
#' \code{VD.model}, a biologically stage-structured model with variable (or
#' stochastic).  Results from the simulation can be compiled with
#' \code{compile.dev.table} for subsequent calculation of population growth
#' rate (\code{VD.solve.euler}), sensitivities, and other quantities.
#' 
#' \code{VD.run} sets up a sequence of calls to \code{\link{VD.run.stage}},
#' which actually does the simulation.  The first call to
#' \code{\link{VD.run.stage}} generates samples of life trajectories that die
#' in stage 1 and that survive stage 1.  The next call uses those that survive
#' stage 1 and appends trajectories that die in stage 2 and that survive stage
#' 2, and so on.  For stages > 1, correlated stage durations based on a
#' Gaussian copula model are used if specified in the \code{VDM} object.
#' 
#' @param VDM A \link{VD.model} object defining a variable development model
#' and simulation controls
#' @param stages Vector of stages to include.  Defaults to all stages
#' (\code{1:numStages(VDM)}).  The vector does not need to go up to the last
#' stage, but it should start at 1 and count up by 1's, such as \code{c(1, 2,
#' 3) }.
#' @param verbose If \code{TRUE}, verbose monitoring of simulation progress is
#' output.  Otherwise the simulation runs silently.
#' @return An object of class \code{\link{VD.sim}}, representing variable
#' development simulation results.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.run.stage}}. Introduction and examples can be found
#' by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.run <- function(VDM, stages = NULL, verbose = FALSE) {
  ans <- VD.sim(VDM);
  if(is.null(stages)) stages <- 1:num.stages(VDM);
  for(iS in stages) {
    ans <- VD.run.stage(VDM, ans, iS, verbose = verbose);
  }
  ans
}



#' Calculate conditional Gaussian means and variance for copula model of
#' correlated stage durations
#' 
#' When a stochastic (or variable) development model uses correlated stage
#' durations defined by a Gaussian copula, the mean and variance of one
#' dimension given the previous dimensions are needed. This function calculates
#' those.  These cannot be pre-calculated because of the sequential Monte Carlo
#' steps, which mean that only the survivors of stage 1 are used for stage 2,
#' and so on.
#' 
#' Uses the first \code{iS} rows and columns of the Gaussian covariance matrix
#' defined in VDM.  Calculates the means (for each simulation in \code{VDS}
#' that survives to stage \code{iS}) and variance (the same value for all) of
#' the \code{iS} dimension of the standard normal marginal deviates that define
#' the quantiles of the stage durations.
#' 
#' This is not typically called by the user.  It is used mainly by
#' \code{\link{VD.run.stage}} and also by
#' \code{\link{VD.solve.fraction.maturing.at.SASD.mc}}.
#' 
#' @param VDM Model definition object of class \code{\link{VD.model}}
#' @param VDS Sequential Monte Carlo simulation result of class
#' \code{\link{VD.sim}} of model \code{VDM}, typically generated by
#' \code{\link{VD.run}} with simulation results through at least stage
#' \code{iS}
#' @param iS Stage index for which conditional information is desired
#' @return A list containing: \item{conditional.means}{Vector of conditional
#' means} \item{conditional.var}{Conditional variance}
#' \item{conditional.sd}{Conditional standard deviation}
#' \item{num.alive}{Number of simulations in \code{VDS} that survive to stage
#' \code{iS}}
#' @author Perry de Valpine
#' @seealso \code{\link{VD.model}}, \code{\link{VD.sim}}. Introduction and
#' examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.calc.conditional.info <- function(VDM, VDS, iS) {

  if(iS < 1 | iS >= num.stages(VDM)) {stop(paste("Error: VD.get.conditional.info got stage", iS, sep = ""));}
  ans<-list()

  Sig11 <- gauss.cov(VDM)[1:iS, 1:iS]
  Sig21 <- matrix(gauss.cov(VDM)[ iS+1, 1:iS], nrow = 1, ncol = iS)
  Sig22 <- gauss.cov(VDM)[(iS + 1), (iS + 1)]
  invSig11 <- solve(Sig11);
  dev.table.Z <- compile.dev.table(VDS, include.dev = FALSE, include.Z = TRUE, survivors = TRUE)$dev.table.Z;

  ans$conditional.means <- as.vector(as.matrix(dev.table.Z) %*% t(Sig21 %*% invSig11));
  ans$conditional.var <- Sig22 - Sig21 %*% invSig11 %*% t(Sig21)
  ans$conditional.sd <- sqrt(ans$conditional.var)
  ans$num.alive <- length(ans$conditional.means)
  ans
}



#' Run one stage of a stochastic (or variable) development population model
#' 
#' Given a variable development model description and previous simulation
#' results for individuals that survive to the requested stage, simulate life
#' trajectories for individuals that die in the requested stage and that
#' survive the requested stage.
#' 
#' \code{VD.run.stage} is primarily intended to be called from
#' \code{\link{VD.run}}.  It uses the \code{VDM} definition, including the
#' controls, to manage the simulation.
#' 
#' @param VDM A \code{\link{VD.model}} object defining a variable development
#' model and simulation controls
#' @param VDS A \code{\link{VD.sim}} object with simulated life trajectories
#' given survival through stage \code{iS-1}.  If \code{iS} is 1, \code{VD.sim}
#' should be an empty \code{VD.sim} object, generated by \code{VD.sim()}
#' @param iS Index of requested stage.  Should follow the last stage contained
#' in \code{VD.sim}.  (This is slightly redundant information but allows some
#' potential flexibility).
#' @param verbose If \code{TRUE}, display verbose monitoring of simulation
#' progress.  Otherwise the simulation runs silently.
#' @return An object of class \code{\link{VD.sim}}, equal to the input argument
#' of the same name for any stages prior to \code{iS}, with the new simulation
#' results filled in for stage \code{iS}.
#' @section Warning: Not much type checking is done.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.run}}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.run.stage <- function(VDM, VDS, iS, verbose = FALSE) {
  indep <- stage.independent(VDM)[iS];
  all.indep <- all.independent(VDM);
  first <- iS == 1
  iSm1 <- iS-1;
  VD.controls.iS <- controls(VDM)[iS,]
  batch.size <- VD.controls.iS$batch.size;
  alive.target <- VD.controls.iS$alive.target;
  dead.target <- VD.controls.iS$dead.target;
  max.dead <- VD.controls.iS$max.dead;
  max.total <- VD.controls.iS$max.total;
  ragged.save <- VD.controls.iS$ragged.save;
  total.count <- alive.count <- dead.count <- 0;
  all.alive.dev.time <- all.alive.dev.time.contin <- all.dead.death.time <- numeric(0)
  if(!all.indep) all.alive.Z<-numeric(0)
  if(!first) all.alive.source.rows <- all.dead.source.rows <- numeric(0)
  if(!indep) {
    conditionalInfo <- VD.calc.conditional.info(VDM, VDS, iSm1);
    conditional.sd <- conditionalInfo$conditional.sd
  }

  if(!first) {
    num.prev.alive <- stageMC(VDS)[[iSm1]]$num.alive;
    source.rows <- 1:num.prev.alive
    i.prev <- 1;
  }

  done <- alive.done <- dead.done <- dead.done.saving <- FALSE;
  alive.discarded <- dead.discarded <- 0
  if(dead.target == 0) dead.done <- TRUE;
  if(max.dead == 0) dead.done.saving <- TRUE
  while(!done) {

    if(!first) this.batch.source.rows <- numeric(0);
    if(!indep) this.batch.conditional.means <- numeric(0);
    if(!first | !indep) {
      num.taken <- 0;
      while(num.taken < batch.size) {
        next.end <- min(num.prev.alive, i.prev + batch.size - num.taken - 1);
        if(!indep) this.batch.conditional.means <- c(this.batch.conditional.means,
                                                     conditionalInfo$conditional.means[i.prev:next.end])
        if(!first) this.batch.source.rows <- c(this.batch.source.rows, source.rows[i.prev:next.end]);
        num.taken <- num.taken + (next.end - i.prev + 1);
        i.prev <- if(next.end == num.prev.alive) 1 else next.end + 1;
      }
    }
    if(!indep) {
      this.batch.conditional.normal <- rnorm(batch.size, this.batch.conditional.means, conditional.sd)
     } else {
      this.batch.conditional.normal <- rnorm(batch.size, 0, 1)
    }
    this.batch.marginal.cumulative <- pnorm(this.batch.conditional.normal)
    this.batch.dev.time.contin <- VD.dist.calc(this.batch.marginal.cumulative, marginal.durations(VDM)[[iS]], "quantile");

    this.batch.dev.time <- ceiling(this.batch.dev.time.contin)
    this.batch.death.time <- ceiling(VD.dist.calc(batch.size, marginal.death.times(VDM)[[iS]], "random"));
    this.batch.survival <- this.batch.death.time > this.batch.dev.time
    this.batch.num.survived <- sum(this.batch.survival)

    if(alive.count + this.batch.num.survived >= alive.target) {
      if(ragged.save) {
        all.alive.dev.time <- c(all.alive.dev.time, this.batch.dev.time[this.batch.survival])
        all.alive.dev.time.contin <- c(all.alive.dev.time.contin, this.batch.dev.time.contin[this.batch.survival])
        if(!all.indep) all.alive.Z <- c(all.alive.Z, this.batch.conditional.normal[this.batch.survival])
        if(!first) all.alive.source.rows <- c(all.alive.source.rows, this.batch.source.rows[this.batch.survival])
        alive.count <- alive.count + this.batch.num.survived;
        alive.discarded <- 0;
      } else {
        if(!alive.done) {
          all.alive.dev.time <- c(all.alive.dev.time, this.batch.dev.time[this.batch.survival][1:(alive.target - alive.count)])
          all.alive.dev.time.contin <- c(all.alive.dev.time.contin, this.batch.dev.time.contin[1:(alive.target - alive.count)])
          if(!all.indep) all.alive.Z <- c(all.alive.Z, this.batch.conditional.normal[this.batch.survival][1:(alive.target - alive.count)])
          if(!first) all.alive.source.rows <- c(all.alive.source.rows, this.batch.source.rows[this.batch.survival][1:(alive.target - alive.count)])
        }
        alive.discarded <- alive.discarded + alive.count + this.batch.num.survived - alive.target
        alive.count <- alive.target;
      }
      alive.done <- TRUE
    } else {
      all.alive.dev.time <- c(all.alive.dev.time, this.batch.dev.time[this.batch.survival])
      all.alive.dev.time.contin <- c(all.alive.dev.time.contin, this.batch.dev.time.contin[this.batch.survival])
      if(!all.indep) all.alive.Z <- c(all.alive.Z, this.batch.conditional.normal[this.batch.survival])
      if(!first) all.alive.source.rows <- c(all.alive.source.rows, this.batch.source.rows[this.batch.survival])
      alive.count <- alive.count + this.batch.num.survived;
    }

    this.batch.num.died <- batch.size - this.batch.num.survived
    if(dead.count + this.batch.num.died >= max.dead) {
      if(max.dead - dead.count >= 1) {
        all.dead.death.time <- c(all.dead.death.time, this.batch.death.time[!this.batch.survival][1:(max.dead - dead.count)])
        if(!first) all.dead.source.rows <- c(all.dead.source.rows, this.batch.source.rows[!this.batch.survival][1:(max.dead - dead.count)])
      }
      dead.discarded <- dead.discarded + dead.count + this.batch.num.died - max.dead
      dead.count <- max.dead;
    } else {
      all.dead.death.time <- c(all.dead.death.time, this.batch.death.time[!this.batch.survival])
      if(!first) all.dead.source.rows <- c(all.dead.source.rows, this.batch.source.rows[!this.batch.survival])
      dead.count <- dead.count + this.batch.num.died
    }

    if(dead.count + dead.discarded > dead.target) dead.done <- TRUE;
    if(dead.done & alive.done) done <- TRUE

    total.count <- total.count + batch.size;
    if(verbose) {
      message(paste("New Batch ", batch.size, this.batch.num.survived, this.batch.num.died))
      message(paste("alive.count", alive.count, length(all.alive.dev.time), ". alive.discared ", alive.discarded, ". dead.count", dead.count, length(all.dead.death.time), ". dead.discarded", dead.discarded, ". total.count", total.count, ". ", alive.done, dead.done, done))
    }

    if(total.count >= max.total) done <- TRUE
  }

  simulation.summary(VDS)[iS,c("Stage", "prob.surv.stage", "total.count", "total.alive", "total.dead", "discarded.alive", "discarded.dead")] <-
    c(iS, (alive.count + alive.discarded) / total.count, total.count, alive.count, dead.count, alive.discarded, dead.discarded)

  stageMC(VDS)[[iS]] <-
  if(!first) {
    if(!all.indep) {
      (list(
                  num.alive = alive.count,
                  aliveT = structure(data.frame(all.alive.dev.time, all.alive.dev.time.contin, all.alive.Z, all.alive.source.rows),
                    names = c("dev.time", "dev.time.contin", "Z", "SourceRow")),
                  deadT = structure(data.frame(all.dead.death.time, all.dead.source.rows), names = c("DeathTime", "SourceRow"))))
    } else {
      (list(num.alive = alive.count,
                  aliveT = structure(data.frame(all.alive.dev.time, all.alive.dev.time.contin, all.alive.source.rows),
                    names = c("dev.time", "dev.time.contin", "SourceRow")),
                  deadT = structure(data.frame(all.dead.death.time, all.dead.source.rows), names = c("DeathTime", "SourceRow"))))

    }
  } else {
    if(!all.indep) {
      (list(
                  num.alive = alive.count,
                  aliveT = structure(data.frame(all.alive.dev.time, all.alive.dev.time.contin, all.alive.Z), names = c("dev.time", "dev.time.contin", "Z")),
                  deadT = structure(data.frame(all.dead.death.time), names = c("DeathTime"))))
    } else {
      (list(num.alive = alive.count,
                  aliveT = structure(data.frame(all.alive.dev.time, all.alive.dev.time.contin), names = c("dev.time", "dev.time.contin")),

            deadT = structure(data.frame(all.dead.death.time), names = c("DeathTime"))))
    }
  }
  VDS
}



#' Compile a development table from sequential Monte Carlo simulations of a
#' variable (stochastic) development model.
#' 
#' The sequential Monte Carlo simulations are originally generated in a compact
#' form, with stage durations or ages-within-stage of death in a table that
#' also includes the row number of the previous stage's simulation, which
#' contains a row number of the previous stage's simulation, etc.  This
#' function pulls the simulations together into a more comprehensible table,
#' which is needed for subsequent analysis such as
#' \code{\link{calc.average.surv.rep.by.age}}.
#' 
#' This is a workhorse function to turn variable development simulation results
#' into more useable forms.
#' 
#' @param VDS An object of class \linkS4class{VD.sim} representing sequential
#' Monte Carlo simulation results of a variable development model.
#' @param final.stage Integer value of the final stage requested in the
#' development table.
#' @param init.stage Initial stage to begin compiling the development table.
#' If this is not 1, results should be interpreted with caution.
#' @param total.age If \code{TRUE}, return \emph{total ages} at which each
#' stage transition occurs.  If \code{FALSE}, return \emph{ages-within-stages}
#' at which each stage transition occurs.
#' @param include.dev If \code{TRUE}, return the development table (in format
#' specificed by \code{total.age})
#' @param include.contin If \code{TRUE}, return a table of the continuous
#' development times that may have been rounded up to get the integer
#' development times.  This always returns \emph{ages-within-stages, not total
#' ages}.
#' @param include.Z If \code{TRUE}, return a table of the standard normal
#' deviates that match the continuous development times in quantiles of the
#' multivariate normal distribution used for a Gaussian copula.
#' @param survivors If \code{TRUE}, the table is made of individuals who
#' \emph{survive} the chosen \code{final.stage}. If \code{FALSE}, the table is
#' made of individuals who \emph{die} in the chosen \code{final.stage}.  Since
#' everyone who survives the last possible stage dies, \code{survivors} should
#' be \code{FALSE} when \code{final.stage} is the last possible stage, i.e.
#' \code{num.stages(VDS)}, and may be \code{TRUE} or \code{FALSE} for other
#' stages.
#' @return A list with components: \item{dev.table }{The development table (if
#' requested) of either total ages or ages-within-stages, given as integers. }
#' \item{dev.table.contin }{The development table (if requested) of
#' ages-within-stages, given as real numbers, even though the actual variable
#' development model uses discrete time steps.} \item{dev.table.Z}{The table
#' (if requested) of standard normal deviates used for the Gaussian copula for
#' correlated stage durations.} \item{survival.weight}{Simulation estimate of
#' dying in stage \code{final.stage}.} \item{stage.kept.weight}{Total number of
#' recorded simulations / number of simulations terminating the in the
#' requested stage and alive-or-dead status.}
#' \item{shared.weight}{survival.weight * stage.kept.weight. For Monte Carlo
#' averages over the full sequential Monte Carlo sample, this is the weight of
#' every life trajectory in the requested category of \code{final.stage} and
#' alive-or-dead status.} \item{MC.sample.size.final.stage}{Number of Monte
#' Carlo samples for stage \code{final.stage}, either alive or dead as chosen.}
#' \item{MC.sample.size.all}{Total Monte Carlo sample size of \code{VDS}.}
#' @author Perry de Valpine
#' @seealso \link{calc.average.surv.rep.by.age}, \link{VD.run},
#' \link{VD.run.stage}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
compile.dev.table <- function(VDS, final.stage = NULL, init.stage = 1, total.age = TRUE, include.dev = TRUE, include.contin = FALSE, include.Z = FALSE, survivors = FALSE) {

  num.stages <- num.stages(VDS);
  if(is.null(final.stage)) final.stage <- length(stageMC(VDS));
  if(final.stage > num.stages | init.stage < 1 | final.stage < init.stage) stop(paste("Error in stage request from ", init.stage, " to ", final.stage,sep=""))
  end.dead <- final.stage < num.stages & !survivors

  requestedStages <- final.stage - init.stage + 1;

  m <- if(!end.dead) {
    stageMC(VDS)[[final.stage]]$num.alive
  } else {
    simulation.summary(VDS)[final.stage, "total.dead"];
  }
  dev.table <- structure(data.frame(matrix(nrow = m, ncol = requestedStages)), names = stage.names(VDS)[init.stage:final.stage])
  if(end.dead) {
    if(include.contin | include.Z) {writeLines(paste("warning: not including contin or Z in compile.dev.table because the last stage has not been requested.", sep = ""));}
    include.contin <- include.Z <- FALSE;
  }
  if(include.contin) dev.table.contin <- dev.table;
  if(include.Z) dev.table.Z <- dev.table;

  survival.weight <- 1;
  total.sim.kept <- 0;

  indexStage <- requestedStages;
  if(!end.dead) {
    if(include.dev) dev.table[ , indexStage] <- stageMC(VDS)[[final.stage]]$aliveT$dev.time;
    if(include.contin) dev.table.contin[ , indexStage] <- stageMC(VDS)[[final.stage]]$aliveT$dev.time.contin;
    if(include.Z) dev.table.Z[, indexStage] <- stageMC(VDS)[[final.stage]]$aliveT$Z;
    SourceRow <- stageMC(VDS)[[final.stage]]$aliveT$SourceRow
    final.sim.kept <- simulation.summary(VDS)[final.stage, "total.alive"]
  } else {
    if(include.dev) dev.table[ , indexStage] <- stageMC(VDS)[[final.stage]]$deadT$DeathTime;
    SourceRow <- stageMC(VDS)[[final.stage]]$deadT$SourceRow
    survival.weight <- survival.weight * (1-simulation.summary(VDS)[final.stage, "prob.surv.stage"])
    final.sim.kept <- simulation.summary(VDS)[final.stage, "total.dead"]
  }
  if(requestedStages > 1) {
    for(thisStage in seq(final.stage - 1, init.stage, by = -1)) {
      indexStage <- indexStage - 1;
      if(include.dev) dev.table[ , indexStage] <- stageMC(VDS)[[thisStage]]$aliveT$dev.time[SourceRow];
      if(include.contin) dev.table.contin[, indexStage] <- stageMC(VDS)[[thisStage]]$aliveT$dev.time.contin[SourceRow];
      if(include.Z) dev.table.Z[, indexStage] <- stageMC(VDS)[[thisStage]]$aliveT$Z[SourceRow];
      survival.weight <- survival.weight * simulation.summary(VDS)[thisStage, "prob.surv.stage"];
      if(thisStage > 1) SourceRow <- stageMC(VDS)[[thisStage]]$aliveT$SourceRow[SourceRow];
    }

    if(total.age & include.dev) {
      if(requestedStages > 1) {
        for(indexStage in 2:requestedStages) {
          dev.table[, indexStage] <- dev.table[, indexStage - 1] + dev.table[, indexStage]
        }
      }
    }
  }

  total.sim.kept <- sum(simulation.summary(VDS)$total.dead[-num.stages]) + simulation.summary(VDS)$total.alive[num.stages]

  stage.kept.weight <-  total.sim.kept / final.sim.kept;

  list(dev.table = if(include.dev) dev.table else NULL,
       dev.table.contin = if(include.contin) dev.table.contin else NULL,
       dev.table.Z = if(include.Z) dev.table.Z else NULL,
       survival.weight = survival.weight,
       stage.kept.weight = stage.kept.weight,
       shared.weight = survival.weight * stage.kept.weight,
       MC.sample.size.final.stage = final.sim.kept,
       MC.sample.size.all = total.sim.kept
       )
}



#' Calculate the left hand side of the Euler equation from a sequential Monte
#' Carlo sample of a variable development model
#' 
#' The left hand side of the Euler (or Euler-Lotka) equation gives the
#' discounted expected reproductive success of an individual in a population
#' changing at rate r.  The value of r that sets the Euler equation to 1 is the
#' long-term population growth rate.
#' 
#' The left-hand-side of the Euler equation is
#' \code{sum(fecundity.by.age$mean.fecundity * exp(-r*fecundity.by.age$age))}.
#' 
#' Note that this is not the function used by \code{\link{VD.solve.euler}},
#' which has its own Euler equation built-in.
#' 
#' @param r Population growth rate
#' @param fecundity.by.age Data frame produced by
#' \code{\link{calc.average.surv.rep.by.age}} for results from
#' \code{\link{VD.run}}
#' @return A number.
#' @author Perry de Valpine
#' @seealso \code{\link{VD.deriv.growth.rate}}, \code{\link{VD.run}}.
#' Introduction and examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
euler <- function(r, fecundity.by.age) {
  sum(fecundity.by.age$mean.fecundity * exp(-r*fecundity.by.age$age))
}

VD.deriv.euler.dr <- function(r, fecundity.by.age) {
  -sum(fecundity.by.age$mean.fecundity * fecundity.by.age$age * exp(-r*fecundity.by.age$age))
}



#' Solve the Euler (or Euler-Lotka) equation for the long-term population
#' growth rate r
#' 
#' The Euler equation states that the discounted expected reproductive output
#' of an individual is 1 when the population is growing at its long-term growth
#' rate.  See \link{euler}.
#' 
#' The interval in which the solution is searched for is from
#' \code{-50/max(fecundity.by.age$age)} to \code{3}.
#' 
#' @param fecundity.by.age Data frame produced by
#' \code{\link{calc.average.surv.rep.by.age}} for results from
#' \code{\link{VD.run}}
#' @param \dots optional arguments to be passed to a call to \link{uniroot}
#' @return The value (r) that solves the Euler equation.
#' @author Perry de Valpine
#' @seealso \link{euler}, \link{calc.average.surv.rep.by.age}, \link{VD.run}.
#' Introduction and examples can be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.solve.euler <- function(fecundity.by.age, ...) {

  z <- fecundity.by.age$age;
  mean.fecundity <- fecundity.by.age$mean.fecundity;
  euler.m1 <- function(r) {
    sum(mean.fecundity * exp(-r*z)) - 1
  }
  lower <- -50/max(z);
  ans <- uniroot(euler.m1, interval = c(lower,3), ...)

  ans$root
}



#' Calculate the expected fecundity of individuals born now when they are at
#' each age.
#' 
#' Using a sequential Monte Carlo sample for a variable (or stochastic)
#' development model, calculate for each possible age the average fecundity
#' attained at that age (including 0 fecundity for individuals dead at that
#' age), averaged over all life trajectories of development and mortality. This
#' is useful for solving the Euler (or Euler-Lotka) equation for long-term
#' population growth rate.
#' 
#' The long-term (or asymptotic) population growth rate, r, is the solution to
#' the Euler or Euler-Lotka equation:
#' 
#' \deqn{\sum_{z = 0}^{\infty} e^{-rz} \left[\mbox{Expected fecundity at age z}
#' \right] = 1}{Sum over all ages z (exp[-rz] * [Expected fecundity at age z])
#' = 1}
#' 
#' These functions calculate the expected fecundity at age z for every age z.
#' \code{calc.average.surv.rep.by.age} is intended to be called by the user or
#' other functions, and it calls
#' \code{\link{calc.average.surv.rep.by.age.funcM}} to do the actual
#' calculations.
#' 
#' @aliases calc.average.surv.rep.by.age calc.average.surv.rep.by.age.funcM
#' @param dev.table Development table produced by
#' \code{\link{compile.dev.table}} from a \linkS4class{VD.sim} variable
#' development simulation object.
#' @param F For \code{calc.average.surv.rep.by.age}, either an object of class
#' \linkS4class{VD.fec}, representing fecundity in a variable development
#' model, or a number representing constant adult fecundity per time step.  For
#' \code{calc.average.surv.rep.by.age.funcM}, \code{m} must be an object of
#' class \linkS4class{VD.fec}.
#' @param weights A vector matching \code{dev.table} in length with weights for
#' each life trajectory in the sample.  These are used for calculation of
#' derivatives, i.e. from \code{\link{VD.deriv.euler}} and should not typically
#' be included from a command-line call.  These are \emph{not} the standard
#' weights from the Sequential Monte Carlo simulations; those are contained in
#' the \code{compile.dev.table} results.
#' @param use.shared.weight If \code{TRUE}, use the shared weights due to
#' sequential Monte Carlo sampling.  This should normally be \code{TRUE}.  Ok
#' to use in combination with \code{weights}.
#' @param deriv.param Character string naming a parameter of \code{m} with
#' respect to which a derivative should be calculated.
#' @return A data frame with two columns: \item{age}{Vector of ages for which
#' average fecundity was calculated.  Includes the full range for which average
#' fecundities are non-zero.} \item{mean.fecundity}{Average fecundity of
#' individuals at each age.  Due to the clockwork of the model, average
#' fecundity of individuals age z is the number of offspring produced in the
#' parent's (z-1)-to-(z) transition that are counted when the parent is or
#' would be age z.  It is possible that the parent died and is not counted at
#' age z, but nevertheless had non-zero fecundity counted for its age z.  Of
#' the possible ways to define the clockwork for a discrete-time population
#' model, this allows a clear correspondence to the fecundity (top) row of a
#' standard matrix population model.}
#' @author Perry de Valpine
#' @seealso \code{\link{euler}}, \code{\link{VD.solve.euler}},
#' \code{\link{compile.dev.table}}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
calc.average.surv.rep.by.age <- function(dev.table, F = NULL, weights = NULL, use.shared.weight = TRUE, deriv.param = NULL) {
  if(is(F, "VD.model")) {
    ans <- calc.average.surv.rep.by.age.funcM(dev.table, F@fecundity, weights = weights, use.shared.weight = use.shared.weight, deriv.param = deriv.param);
  } else {
    if(is.numeric(F)) {
      F #force evaluation.
      fec <- VD.fec(VD.fecundity.constant, list(F = F));
      ans <- calc.average.surv.rep.by.age.funcM(dev.table, F = fec, weights = weights, use.shared.weight = use.shared.weight, deriv.param = deriv.param)
    } else {
      ans <- calc.average.surv.rep.by.age.funcM(dev.table, F = F, weights = weights, use.shared.weight = use.shared.weight, deriv.param = deriv.param)
    }
  }
  ans
}


calc.average.surv.rep.by.age.funcM <- function(dev.table, F, weights = NULL, use.shared.weight = TRUE, deriv.param = NULL) {
  colDie <- dim(dev.table$dev.table)[2];
  colMature <- colDie - 1;
  ageDie <- dev.table$dev.table[,colDie];
  if(colMature > 0 ){
    ageMature <- dev.table$dev.table[,colMature];
  } else {
    ageMature <- rep(0, length(ageDie));
  }
  zMin <- min(ageMature);
  zMax <- max(ageDie);
  numZ <- zMax - zMin + 1;
  ans <- data.frame(age = zMin:zMax, mean.fecundity = rep(NA, numZ))
  z <- zMin;
  anscol <- rep(0, numZ);
  if(is.null(deriv.param)) {
    if(is.null(weights)) {
      for(iz in 1:numZ) {
        anscol[iz] <- sum(VD.fec.calc(age = z, age.maturity = ageMature[ageMature < z & ageDie >= z], F));
        z <- z+ 1;
      }
      ans[,2] <- anscol;
    } else {
      for(iz in 1:numZ) {
        bool <- ageMature < z & ageDie >= z
        anscol[iz] <-sum(VD.fec.calc(age = z, age.maturity = ageMature[bool], F ) * weights[bool]);
        z <- z + 1;
      }
      ans[,2] <- anscol;
    }
  } else {
    if(is.null(weights)) {
      for(iz in 1:numZ) {
        anscol[iz] <- sum(VD.fec.deriv(age = z, age.maturity = ageMature[ageMature < z & ageDie >= z], F, param = deriv.param));
        z <- z+ 1;
      }
      ans[,2] <- anscol;
    } else {
      for(iz in 1:numZ) {
        bool <- ageMature < z & ageDie >= z
        anscol[iz] <- sum(VD.fec.deriv(age = z, age.maturity = ageMature[bool], F ) * weights[bool], param = deriv.param);
        z <- z + 1;
      }
      ans[,2] <- anscol;
    }

  }
  if(use.shared.weight) {
    ans[,2] <- ans[,2] * dev.table$shared.weight / dev.table$MC.sample.size.all
  } else {
    ans[,2] <- ans[,2] / dev.table$MC.sample.size.all
  }
  ans
}




#' Create information about the stable age and stage distributions of a
#' variable development model from a sequential Monte Carlo sample
#' 
#' Create information about the stable age and stage distributions of a
#' variable development model from a sequential Monte Carlo sample
#' 
#' 
#' @param VDS A variable development simulation of class \linkS4class{VD.sim}
#' @param r Long-term population growth-rate, i.e. solution to Euler equation
#' obtained by \code{\link{VD.solve.euler}}
#' @return A \linkS4class{VD.SASD} object, which is a list with components:
#' \item{SASD }{A matrix with rows indexed by age and columns by stage.  Each
#' entry has the fraction of the population in that age-stage combination at
#' the stable age-stage distribution.} \item{SSD }{Stable stage distribution: A
#' vector indexed by stage of the fraction in each stage.}
#' \item{maturing.frac}{Vector indexed by stage of the fraction of each stage
#' maturing, given survival, at each time step} \item{dying.frac}{Vector
#' indexed by stage of the fraction of each stage dying at each time step}
#' \item{age.vector}{Age vector corresponding to rows of \code{SASD}}
#' @author Perry de Valpine
#' @seealso \linkS4class{VD.SASD}. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
make.SASD <- function(VDS, r) {
  num.stages <- num.stages(VDS);
  final.stage <- num.stages;
  dev.tables.alive <- list();
  dev.tables.dead <- list();
  for(iS in 1:final.stage) {
    DT <- compile.dev.table(VDS, iS);
    dev.tables.dead[[iS]] <- DT$dev.table
  }
  if(final.stage > 1) {
    for(iS in 1:(final.stage - 1)) {
      DT <- compile.dev.table(VDS, iS, survivors = TRUE);
      dev.tables.alive[[iS]] <- DT$dev.table;
    }
  }
  max.age <- max(dev.tables.dead[[final.stage]][, final.stage]);
  age.vector <- 1:max.age;
  num.ages <- length(age.vector);
  dying.ASD <- maturing.ASD <- SASD <- matrix(0, ncol = final.stage, nrow = num.ages);

  prob.surv.stage <- simulation.summary(VDS)$prob.surv.stage;
  nj.alive <- simulation.summary(VDS)$total.alive;
  nj.dead <- simulation.summary(VDS)$total.dead;

  for(iS in 1:final.stage) {
    if(iS > 1) {
      if(iS < final.stage) {
        nT <- nj.alive[iS] + nj.dead[iS];
        weight.dead <- prod(prob.surv.stage[1:(iS - 1)]) * (1-prob.surv.stage[iS]) / (nj.dead[iS] / nT);
        weight.alive <- prod(prob.surv.stage[1:iS]) / (nj.alive[iS] / nT);
        this.age.range <- c(min(dev.tables.dead[[iS]][, iS-1], dev.tables.alive[[iS]][, iS - 1]),
                            max(dev.tables.dead[[iS]][, iS], dev.tables.alive[[iS]][, iS]))
        for(a in seq(this.age.range[1], this.age.range[2])) {
          ai <- a;
          SASD[ai, iS] <- (weight.dead * sum(dev.tables.dead[[iS]][, iS] >= a & dev.tables.dead[[iS]][, iS-1] < a) +
            weight.alive * sum(dev.tables.alive[[iS]][, iS] >= a & dev.tables.alive[[iS]][, iS-1] < a))/nT;
          maturing.ASD[ai, iS] <- weight.alive * sum(dev.tables.alive[[iS]][, iS] == a) / nT;
          dying.ASD[ai, iS] <- weight.dead * sum(dev.tables.dead[[iS]][, iS] == a) / nT;
        }
      } else { # iS == final.stage
        nT <- nj.alive[iS]; ## these are "matured" from final stage, i.e. dead
        weight.dead <- prod(prob.surv.stage[1:(iS - 1)]) * 1;
        this.age.range <- c(min(dev.tables.dead[[iS]][, iS-1]),
                            max(dev.tables.dead[[iS]][, iS]));
        for(a in seq(this.age.range[1], this.age.range[2])) {
          ai <- a ;
          SASD[ai, iS] <- weight.dead * sum(dev.tables.dead[[iS]][, iS] >= a & dev.tables.dead[[iS]][, iS-1] < a) / nT;
          dying.ASD[ai, iS] <- weight.dead * sum(dev.tables.dead[[iS]][, iS] == a) / nT;
        }
      }
    } else { ## iS == 1
      if(iS < final.stage) {
        nT <- nj.alive[iS] + nj.dead[iS];
        weight.dead <- (1-prob.surv.stage[iS]) / (nj.dead[iS] / nT);
        weight.alive <- (prob.surv.stage[iS]) / (nj.alive[iS] / nT);

        this.age.range <- c(0,
                            max(dev.tables.dead[[iS]][, iS], dev.tables.alive[[iS]][, iS]))
        for(a in seq(this.age.range[1], this.age.range[2])) {
          ai <- a;
          SASD[ai, iS] <- (weight.dead * sum(dev.tables.dead[[iS]][, iS] >= a) +
            weight.alive * sum(dev.tables.alive[[iS]][, iS] >= a)) / nT;
          maturing.ASD[ai, iS] <- weight.alive * sum(dev.tables.alive[[iS]][, iS] == a) / nT;
          dying.ASD[ai, iS] <- weight.dead * sum(dev.tables.dead[[iS]][, iS] == a) / nT;
        }
      } else { # iS == final.stage
        nT <- nj.dead[iS];
        this.age.range <- c(0,
                            max(dev.tables.dead[[iS]][, iS]));
        for(a in seq(this.age.range[1], this.age.range[2])) {
          ai <- a;
          SASD[ai, iS] <- sum(dev.tables.dead[[iS]][, iS] >= a) / nT;
          dying.ASD[ai, iS] <- sum(dev.tables.dead[[iS]][, iS] == a) / nT;
        }
      }
    }
  }
  # Do tallies.
  discounts <- exp(-r * (age.vector - 1));
  for(iS in 1:final.stage) {
    SASD[, iS] <- SASD[, iS] * discounts;
    dying.ASD[, iS] <- dying.ASD[, iS] * discounts;
    maturing.ASD[, iS] <- maturing.ASD[, iS] * discounts;
  }

  SSD <- apply(SASD, 2, sum)
  maturing.frac <- dying.frac <- numeric(num.stages);
  for(iS in 1:final.stage) {
    dying.frac[iS] <- sum(dying.ASD[,iS])/SSD[iS]
  }

  for(iS in 1:final.stage) {
    maturing.frac[iS] <- sum(maturing.ASD[,iS]) / SSD[iS]
  }
  total <- sum(SSD);
  SASD <- SASD/total;
  SSD <- SSD/total;


  as.VD.SASD(list(SASD = SASD,
                  SSD = SSD,
                  maturing.frac = maturing.frac,
                  dying.frac = dying.frac,
                  age.vector = age.vector))

}

VD.deriv.growth.rate <- function(VDM, r, dev.table, fecundity.by.age, stage = NULL, death = NULL, fecundity = NULL, param = NULL, force.numerical = FALSE, make.discrete = FALSE, delta = NULL, F = NULL) {
  denom <- VD.deriv.euler.dr(r, fecundity.by.age);
  numer <- VD.deriv.euler(VDM, r, dev.table, fecundity.by.age, stage, death, fecundity, param, force.numerical, make.discrete, delta, F)
  -numer/denom
}



#' Calculate derivatives of the Monte Carlo approximation to the Euler equation
#' and of population growth rate
#' 
#' The solution to the Euler equation gives the long-term population growth
#' rate. Derivatives of population growth rate are needed for the demographic
#' sensitivities.  These derivatives are done by implicit differentiation,
#' using the derivatives of the Euler equation with respect to r and with
#' respect to a parameter of the variable development model.  The latter can be
#' calculated for any model parameter, using a numerical derivative if
#' necessary.  Derivatives involving copula models are no implemented yet.
#' 
#' \code{VD.deriv.growth.rate} gives the derivative of population growth rate
#' by implicit differentiation as the negative of the ratio of
#' \code{VD.deriv.euler} and \code{VD.deriv.euler.dr}.
#' 
#' \code{VD.deriv.euler} gives the derivative of population growth rate, r,
#' with respect to any parameter of a stage duration distribution,
#' age-within-stage of death distribution, or the fecundity model in
#' \code{VDM}.
#' 
#' \code{VD.deriv.euler.dr} gives the derivative of the Euler equation with
#' respect to r, the population growth rate, evaluated at the value of r that
#' solves the equation.
#' 
#' For derivatives with respect to stage duration and death distribution
#' parameters, \code{VD.deriv.euler} calls \code{\link{VD.dist.deriv}}.
#' 
#' @aliases VD.deriv.euler VD.deriv.growth.rate VD.deriv.euler.dr
#' @param VDM A variable development model object of class
#' \linkS4class{VD.model}.
#' @param r Long-term population growth rate (i.e. solution to the Euler
#' equation), typically obtained by \code{\link{VD.solve.euler}}.
#' @param dev.table Development table for model \code{VDM} obtained from
#' sequential Monte Carlo simulation, typically obtained by
#' \code{make.dev.table} with the results of \code{VD.run(VDM)}
#' @param fecundity.by.age Data frame returned by
#' \code{calc.average.surv.rep.by.age}
#' @param stage If non-NULL, an integer indicating which stage duration
#' distribution has the parameter for the derivative. \emph{Only one of
#' \code{stage}, \code{survival}, or \code{fecundity} should be non-NULL.}
#' @param death If non-NULL, an integer indicating which age-within-stage of
#' death distribution has the parameter for derivative
#' @param fecundity If non-NULL, derivative is for a parameter of the fecundity
#' distribution (actual value of \code{fecundity} is not used, just whether or
#' not it is NULL).
#' @param param Character string naming a parameter with respect to which the
#' derivative should be calculated.
#' @param force.numerical If \code{TRUE}, use a numerical derivative even if a
#' derivative function is known by \code{VDM}.0
#' @param make.discrete If \code{TRUE}, force the values in the dev.table to be
#' discretized to integers and derivative to be done appropriately.
#' @param delta Small change in parameter value to be used for numerical
#' derivative.  If \code{NULL}, a default used by the \linkS4class{VD.dist} or
#' \linkS4class{VD.fec} objects in \code{VDM} is used.
#' @param F If \code{fecundity} is non-NULL, an object of class \code{VD.fec}
#' or a number for constant adult fecundity.  This is passed to
#' \code{\link{calc.average.surv.rep.by.age}}.
#' @return A number giving the requested derivative.
#' @section Warning: Derivatives involving copula models are not yet
#' implemented.
#' @author Perry de Valpine
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
VD.deriv.euler <- function(VDM, r, dev.table, fecundity.by.age, stage = NULL, death = NULL, fecundity = NULL, param = NULL, force.numerical = FALSE, make.discrete = FALSE, delta = NULL, F = NULL) {
  ## must get non-age-total dev times with contin if needed.

  use.stage <- !is.null(stage)
  use.death <- !is.null(death)
  use.fecundity <- !is.null(fecundity)
  if(sum(use.stage, use.death, use.fecundity) != 1) stop ("Error, must specify exacty one of stage, death, or fecundity");

  if(is.null(param)) {stop("Error: Must specify a param.");}
  if(!is.character(param)) {stop("Error: param must be a string.");}

  derivFunName <- paste("DerivToP.ratio.", param, sep = "");

  if(use.stage) {
    if(!is.numeric(stage)) {stop("Error: stage must be numerical.");}
    tableName <- "dev.table.contin" #to avoid total.age #if(!is.null(dev.table[["dev.table.contin"]])) "dev.table.contin" else "dev.table"
    if(is.null(dev.table[[tableName]])) {stop("Error: you must have dev.table.contin in dev.table");}
    if(stage < 0 | stage > num.stages(VDM)) {stop("Error: stage is out of range.");}

    if(stage.independent(VDM)[stage]) {
      if(make.discrete) {
        deriv.w.d.param <- VD.dist.deriv(dev.table[[tableName]][, stage], marginal.durations(VDM)[[stage]], "pdf", param, make.discrete = TRUE, force.numerical = force.numerical, relative = TRUE);
      } else {
        if(tableName == "dev.table") writeLines("Warning: This is only correct if the stage distribution is inherently discrete.")
        deriv.w.d.param <- VD.dist.deriv(dev.table[[tableName]][, stage], marginal.durations(VDM)[[stage]], "pdf", param, make.discrete = FALSE, force.numerical = force.numerical, relative = TRUE);
      }
    } else {
      ## now force.numerical can be a vector of two logicals, first for the overall deriv, the other for the dF(t)/d theta.
      #deriv.w.d.param <- VD.copula.deriv(dev.table[[tableName]][, stage], VDM, dev.table$Z, stage = stage, param = param, force.numerical = force.numerical, relative = TRUE);
      stop("Error: derivatives for copula models are not implemented yet.");
    }
  }

  if(use.death) {
    if(make.discrete) {writeLines("Warning: make.discrete does not do anything for a death derivative.");}
    if(!is.numeric(death)) {stop("Error: death must give a stage index.");}
    if(is.null(dev.table[["dev.table.contin"]])) {stop("Error: you must have dev.table.contin in dev.table");}
    values <- ceiling(dev.table$dev.table.contin[, death]) ## use dev.table.contin to avoid cumulative ages (total.age)
    deriv.w.d.param <- VD.dist.deriv(values, marginal.death.times(VDM)[[death]], "cdf", param, force.numerical = force.numerical, relative = TRUE, new.params = list(lower.tail = FALSE));
  }

  if(use.fecundity) {
    return(euler(r, calc.average.surv.rep.by.age(dev.table, F, use.shared.weight = TRUE, deriv.param = param)))
  } else {
    return(euler(r, calc.average.surv.rep.by.age(dev.table, F, weights = deriv.w.d.param, use.shared.weight = TRUE)))
  }
}




#' Calculate and optimize the fraction of a stage maturing at stable age-stage
#' distribution of a variable development model
#' 
#' At the stable age-stage distribution of a stochastic (or variable)
#' development model, a fixed fraction of individuals in a stage mature at the
#' next time step, of those who survive to the next time step.  For determining
#' what stochastic development models give the same stable stage distribution
#' and same fractions maturing and dying from each stage at each time step, one
#' can pick a family of distributions for a stage duration that has a free
#' parameter that can be chosen to match the desired fraction maturing.
#' \code{lfraction.maturing.at.SASD.independent} calculate the log fraction for
#' the case of independent stage durations.
#' \code{VD.solve.fraction.maturing.at.SASD.independent} function finds the
#' value of a model parameter that makes the fraction maturing match a given
#' value.
#' 
#' For the case of constant survival per time step, these calculations are
#' equivalent to equation 6.111 of Caswell (2001).
#' 
#' @aliases lfraction.maturing.at.SASD.independent
#' VD.solve.fraction.maturing.at.SASD.independent
#' @param VD.dist.dev An object of class \code{\link{VD.dist}} defining the
#' stage duration distribution
#' @param VD.dist.surv An object of class \code{\link{VD.dist}} defining the
#' mortality distribution
#' @param r Long-term population growth rate, typically obtained from
#' \code{\link{VD.solve.euler}}
#' @param subtract.val A constant value to be subtracted from the log fraction
#' maturing.  This facilitates solving for a desired log fraction maturing
#' using \code{\link{uniroot}}, as in
#' \code{\link{VD.solve.fraction.maturing.at.SASD.independent}}
#' @param fraction.maturing The desired fraction of the stage maturing, given
#' survival, at each time step under the stable age-stage distribution.
#' \code{VD.solve.fraction.maturing.at.SASD.independent} finds parameter values
#' such that the model gives the \code{fraction.maturing}.
#' @param param String naming the parameter of \code{VD.dist.surv} that should
#' be searched to match the \code{fraction.maturing}.
#' @param range A vector of length 2 giving the minimum and maximum values for
#' finding the solution for \code{param}.
#' @param max.age The maximum age-within-stage to consider in summing maturing
#' and surviving individuals.  If \code{NULL}, the lesser of the 0.9999
#' quantiles for the development and survival distributions will be used.  For
#' repeated calls such as from
#' \code{\link{VD.solve.fraction.maturing.at.SASD.independent}}, there are two
#' advantages to specifiying \code{max.age}: it is more efficient not to
#' calculate it on each call, and it keeps the root finding problem smooth by
#' not having the range of the sum change for different values of whatever
#' parameter is being varied.
#' @param VD.dist.dev.replace An optional list with names that are parameter
#' names of \code{VD.dist.dev} and values that are the values to be used for
#' corresponding parameters.  Allowing parameters to be changed in this way
#' facilitates calls to \code{lfraction.maturing.at.SASD.independent} from
#' \code{VD.solve.fraction.maturing.at.SASD.independent}.  See
#' \code{VD.dist.calc}.
#' @param details If TRUE, return the object returned by \code{\link{uniroot}}.
#' Otherwise (default) just return the root.
#' @return For \code{lfraction.maturing.at.SASD.independent}, a number giving
#' the log fraction maturing minus the \code{subtract.val}.
#' 
#' For \code{VD.solve.fraction.maturing.at.SASD.independent}, the value of
#' parameter \code{param} that leads to the desired \code{fraction.maturing}.
#' @author Perry de Valpine
#' @seealso \link{lfraction.maturing.at.SASD.mc},
#' \link{VD.solve.fraction.maturing.at.SASD.mc}. Introduction and examples can
#' be found by \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
lfraction.maturing.at.SASD.independent <- function(VD.dist.dev, VD.dist.surv, r = 0, subtract.val = 0, max.age = NULL, VD.dist.dev.replace = NULL) {
  if(is.null(max.age)) max.age <- ceiling( min(VD.dist.calc(0.9999, VD.dist.surv, "quantile"),
       VD.dist.calc(0.9999, VD.dist.dev, "quantile") ) )

  if(max.age < 1) return(NA);
  age.vector <- 1:max.age;
  if(is.null(VD.dist.dev.replace)) {
    g.dev <- VD.dist.calc(age.vector, VD.dist.dev, "pdf", make.discrete = TRUE);
  } else {
    g.dev <- VD.dist.calc(age.vector, VD.dist.dev, "pdf", make.discrete = TRUE, new.params = VD.dist.dev.replace);
  }
  h.dev <- c(1, 1 - cumsum(g.dev)[1:(max.age-1)]); # this is probability that maturation is greater than or equal to a
  h.surv <- c(1, 1 - VD.dist.calc(age.vector, VD.dist.surv, "cdf", make.discrete = TRUE)[1:(max.age-1)]); #prob death is greater than or equal to a

  growth.discounts <- exp(-r * (age.vector-1));
  numerator <- sum( (growth.discounts[1:(max.age-1)] * h.surv[2:max.age] * g.dev[1:(max.age-1)]) )
  denominator <- sum( growth.discounts[1:(max.age-1)] * h.surv[2:max.age] * h.dev[1:(max.age-1)])

  log(numerator) - log(denominator) - subtract.val
}

VD.solve.fraction.maturing.at.SASD.independent <- function(VD.dist.dev, VD.dist.surv, r, fraction.maturing, param, range, max.age = NULL, details = FALSE) {
  lfraction.maturing <- log(fraction.maturing)
  replace.param <- list();
  replace.param[[param]] <- 0;
  objective <- function(v) {
    replace.param[[1]] <- v;
    lfraction.maturing.at.SASD.independent(VD.dist.dev, VD.dist.surv, r, lfraction.maturing, VD.dist.dev.replace = replace.param, max.age = max.age);
  }
  ans <- uniroot(objective, range);
  if(details) ans else ans$root
}

lfraction.maturing.at.SASD.mc.dev.only <- function(VDM, VD.dist.dev, r, marg.cum, h.surv, age.prev, replace.param, age.vector, subtract.val = 0 ) {

  dev.time.contin <- VD.dist.calc(marg.cum, VD.dist.dev, "quantile", new.params = replace.param);
  dev.time <- ceiling(dev.time.contin);
  dev.age <- dev.time + age.prev;
  h.surv <- c(h.surv, 0); ## should never need the 0, but at least it will prevent an error if needed.
  maturing <- surviving <- rep(0, length(age.vector));
  for(a in age.vector) {
    ai <- a;
    bool <- dev.age >= a & age.prev < a;
    bool.now <- dev.age == a;
    age.in.stage <- a - age.prev;
    maturing[ai] <-  sum(h.surv[ age.in.stage[bool.now] + 1 ]);
    surviving[ai] <- sum(h.surv[ age.in.stage[bool] + 1 ]);
    bool.keep <- dev.age >= a;
    dev.age <- dev.age[bool.keep];
    age.prev <- age.prev[bool.keep];
  }

  discounts <- exp(-r * (age.vector-1))
  frac.mat <- sum(discounts * maturing) / sum(discounts * surviving);
  log(frac.mat) - subtract.val
}




#' Calculate and optimize the fraction maturing given survival at each time
#' step of a variable development model allowing correlations among stage
#' durations
#' 
#' At the stable age-stage distribution of a stochastic (or variable)
#' development model, a fixed fraction of individuals in a stage mature at the
#' next time step, of those who survive to the next time step.  For determining
#' what stochastic development models give the same stable stage distribution
#' and same fractions maturing and dying from each stage at each time step, one
#' can pick a family of distributions for a stage duration that has a free
#' parameter that can be chosen to match the desired fraction maturing.
#' \code{lfraction.maturing.at.SASD.mc} and
#' \code{lfraction.maturing.at.SASD.mc.dev.only} calculate the log fraction.
#' \code{VD.solve.fraction.maturing.at.SASD.mc} finds the value of a model
#' parameter that makes the fraction maturing match a given value.  These
#' methods use sequential Monte Carlo simulations to allow correlated stage
#' durations.
#' 
#' \code{lfraction.maturing.at.SASD.mc} works entirely by Monte Carlo
#' integration.  Its method for Monte Carlo summation is similar to that in
#' \code{\link{make.SASD}}.
#' 
#' \code{lfraction.maturing.at.SASD.dev.only} uses Monte Carlo samples of
#' development times but direct calculation of survival probabilities, allowing
#' a more accurate result.
#' 
#' \code{VD.solve.fraction.maturing.at.SASD.mc} finds the value of a parameter
#' that gives the desired fraction maturing.
#' 
#' @aliases lfraction.maturing.at.SASD.mc
#' lfraction.maturing.at.SASD.mc.dev.only VD.solve.fraction.maturing.at.SASD.mc
#' @param VDM Variable development model of class \linkS4class{VD.model}
#' @param iStage Integer index of the stage for which the stage duration model
#' should be solved
#' @param VD.dist.dev stage duration distribution of class
#' \linkS4class{VD.dist} for the next stage, i.e. the stage for which the log
#' fraction maturing is requested
#' @param VD.dist.surv Survival (age-within-stage of death) distribution of
#' class \linkS4class{VD.dist} for the next stage.
#' @param r Population growth rate, i.e. solution to the Euler equation
#' obtained by \code{\link{VD.solve.euler}}
#' @param fraction.maturing The desired fraction maturing
#' @param param Character string of the name of the parameter of
#' \code{VD.dist.dev} that should be searched for a value to obtain
#' \code{fraction.maturing}
#' @param range Vector of 2 numbers giving the min and max of the range to
#' search for \code{param}
#' @param n Monte Carlo sample size to use for the final stage
#' @param details If \code{TRUE}, \code{VD.solve.fraction.maturing.at.SASD.mc}
#' returns the object returned by its call to \code{\link{uniroot}}.  Otherwise
#' it returns the solution value of the \code{param}.
#' @param mc.dev.only If \code{TRUE}, the Monte Carlo will be used for the
#' stage duration only, not the survival, i.e.
#' \code{lfraction.maturing.at.SASD.mc.dev.only} will be used, not
#' \code{lfraction.maturing.at.SASD.mc}.
#' @param marg.cum Vector of quantiles (cumulative probabilities) for the stage
#' durations of the next stage
#' @param death.time Vector of ages-within-stage of death
#' @param age.prev Vector of ages of the previous stage transition
#' @param replace.param Optional list with names matching parameters if
#' \code{VD.dist.dev} and values to be plugged in for the corresponding
#' parameters.  Facilitates calling this function by
#' \code{\link{VD.solve.fraction.maturing.at.SASD.mc}}
#' @param max.age Maximum age to consider in summations.
#' @param subtract.val A constant value to be subtracted from the log fraction
#' maturing, faciliting calls from \link{uniroot}
#' @param h.surv Vector of probabilities that death occurs at greater than or
#' equal to each age in \code{age.vector}
#' @param age.vector Vector of ages over which summations should be done
#' @return For \code{lfraction.maturing.at.SASD.mc} and
#' \code{lfraction.maturing.at.SASD.dev.only}, the log fraction maturing.
#' 
#' For \code{VD.solve.fraction.maturing.at.SASD.mc}, the value of the parameter
#' giving the desired fraction maturing.
#' @author Perry de Valpine
#' @seealso \link{lfraction.maturing.at.SASD.independent},
#' \link{VD.solve.fraction.maturing.at.SASD.independent} for independent stage
#' durations. Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
lfraction.maturing.at.SASD.mc <- function(VDM, VD.dist.dev, r, marg.cum, death.time, age.prev, replace.param, max.age, subtract.val = 0 ) {
  dev.time.contin <- VD.dist.calc(marg.cum, VD.dist.dev, "quantile", new.params = replace.param);
  dev.time <- ceiling(dev.time.contin);
#  surv.bool <- death.time > dev.time;
#  die.bool <- !surv.bool;
  dev.age <- dev.time + age.prev;
  die.age <- death.time + age.prev;
  age.vector <- 1:max.age;
  maturing <- surviving <- rep(0, max.age)
  for(a in age.vector) {
    ai <- a;
    bool <- die.age > a & dev.age >= a;
    maturing[ai] <- sum(dev.age == a & bool);
    surviving[ai] <- sum(bool & age.prev < a);
    die.age <- die.age[bool];
    dev.age <- dev.age[bool];
    age.prev <- age.prev[bool];
  }

  discounts <- exp(-r * (age.vector-1))
  frac.mat <- sum(discounts * maturing) / sum(discounts * surviving);
  log(frac.mat) - subtract.val
}

VD.solve.fraction.maturing.at.SASD.mc <- function(VDM, iStage = -1, VD.dist.dev, VD.dist.surv, r, fraction.maturing, param, range,
                                               n = 10000, max.age = NULL, details = FALSE, mc.dev.only = FALSE) {

  lfraction.maturing <- log(fraction.maturing);
  replace.param <- list();
  replace.param[[param]] <- 0;
  if(iStage > 1) {
    VDS <- VD.run(VDM, 1:(iStage-1))
  } else {
    VDS <- VD.sim(VDM);
  }
  dev.table <- compile.dev.table(VDS, total.age = TRUE, survivors = TRUE);
  age.prev <- rep(dev.table$dev.table[, iStage - 1], length.out = n); # count on correspondence to rep(...) below

  if(iStage > 1) {
    conditionalInfo <- VD.calc.conditional.info(VDM, VDS, iStage-1);
    conditionalMeans <- rep(conditionalInfo$conditional.means, length.out = n);
    conditionalSD <- conditionalInfo$conditional.sd;
  } else {
    conditionalMeans <- rep(0, n);
    conditionalSD <- 1;
  }
  cond.norm <- rnorm(n, conditionalMeans, conditionalSD);
  marg.cum <- pnorm(cond.norm);
  if(missing(VD.dist.surv)) VD.dist.surv <- marginal.death.times(VDM)[[iStage]];

  if(mc.dev.only) {
    age.vector <- 1:max.age;
    h.surv <- c(1, 1 - VD.dist.calc(age.vector, VD.dist.surv, "cdf", make.discrete = TRUE)[1:(max.age)]); #prob death is greater than or equal to a
    objective <- function(v) {
      replace.param[[1]] <- v;
      lfraction.maturing.at.SASD.mc.dev.only(VDM, VD.dist.dev, r,  marg.cum, h.surv, age.prev, replace.param, age.vector, lfraction.maturing)
    }
  } else {
    death.time <- ceiling(VD.dist.calc(n, VD.dist.surv, "random"));
    objective <- function(v) {
      replace.param[[1]] <- v;
      lfraction.maturing.at.SASD.mc(VDM, VD.dist.dev, r,  marg.cum, death.time, age.prev, replace.param, max.age, lfraction.maturing)
    }
  }

  ans <- try(uniroot(objective, interval = range));
  if(inherits(ans, "try-error")) return(NA)
  if(details) ans else ans$root
}



#' Calculate the correlation coefficient of two stage durations that are
#' jointly distributed according to a Gaussian copula model
#' 
#' For variable (or stochastic) development models, stage duration
#' distributions can be correlation by a Gaussian copula in
#' \linkS4class{VD.model} objects and simulations by \link{VD.run}.  It may be
#' of interest to know the correlation of the development times created by the
#' copula model.  In a variable development model, mortality may complicate
#' interpretation of the correlations because one has to be careful about
#' whether the correlations are conditioned on survival.  In this function,
#' survival is set to 1 (or time-of-death to infinite), so that only the stage
#' duration distribution is involved in the correlations.
#' 
#' This constructs a \linkS4class{VD.model} object with
#' \code{marginal.durations} of \code{dist1} and \code{dist2} and no mortality.
#' 
#' @param dist1 A \linkS4class{VD.dist} object defining the first stage
#' @param dist2 A \linkS4class{VD.dist} object defining the second stage
#' @param rho correlation coefficient for the Gaussian copula
#' @return A list with components \item{cor.norm }{Correlation of the standard
#' normal deviates simulated for the correlated stages.  This should be
#' \code{rho} (within sampling error) or something is wrong.}
#' \item{cor.dev.time }{Correlation in the integer development times (stage
#' durations).} \item{cor.dev.time.contin}{Correlation in the continuous
#' deviates (if applicable) that were rounded up to get the integer development
#' times.}
#' @author Perry de Valpine
#' @seealso Introduction and examples can be found by
#' \code{vignette("varDev")}.
#' @references P. de Valpine. 2002. Stochastic development in biologically
#' structured population models.  Ecology 90:2889-2901.
calc.copula.correlations <- function(dist1, dist2, rho) {

  gauss.cov <- matrix(c(1, rho, rho, 1), c(2,2));
  VDM <- VD.model(2, marginal.durations = list(dist1, dist2), marginal.death.times = list(VD.dist("infinite"), VD.dist("infinite")), gauss.cov = gauss.cov)
  controls(VDM)$dead.target <- 0;
  VDS <- VD.run(VDM);
  dev.table <- compile.dev.table(VDS, total.age = FALSE, include.contin = TRUE, include.Z = TRUE);
  corZ = cor(dev.table$dev.table.Z[,1], dev.table$dev.table.Z[,2]);
  cordtI = cor(dev.table$dev.table[,1], dev.table$dev.table[,2]);
  cordtC = cor(dev.table$dev.table.contin[,1], dev.table$dev.table.contin[,2]);
  list(cor.norm = corZ, cor.dev.time = cordtI, cor.dev.time.contin = cordtC);
}
